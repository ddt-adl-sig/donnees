# -*- coding: utf-8 -*-
"""***************************************************************************
    copyright            : Philippe Desboeufs
    begin                : 2017-11-29
   ***************************************************************************
   *   This program is free software; you can redistribute it and/or modify  *
   *   it under the terms of the GNU General Public License as published by  *
   *   the Free Software Foundation; either version 2 of the License, or     *
   *   (at your option) any later version.                                   *
   ***************************************************************************
"""
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.gui import *
import os.path, time, math
from qgis.utils import iface
geometryTypes= {-1:'Invalid',0:'Unknown',1:'Point',2:'LineString',3:'Polygon',4:'MultiPoint',5:'MultiLineString',6:'MultiLineString',7:'GeometryCollection'} # Nomenclature complete dans QgsWkbTypes.Ttpe

class plugin:
  def __init__(self, iface):
    self.plugin_dir= os.path.dirname(__file__)

  def initGui(self):
    pluginPath= os.path.abspath(os.path.dirname(__file__))
    # Create action that will start plugin configuration
    icone= pluginPath + os.sep +"balai.png"
    self.clean= QAction( QIcon(icone), u"Corriger les polygones non valides", iface.mainWindow() )
    self.clean.triggered.connect(self.dialogMakeValid)
    iface.addToolBarIcon(self.clean)
    
    icone= pluginPath + os.sep +"icon.png"
    self.cut= QAction( QIcon(icone), u"Rechercher / Eliminer les superpositions de polygones", iface.mainWindow() )
    self.cut.triggered.connect(self.dialogOverlapping)
    iface.addToolBarIcon(self.cut)
    
    self.nomDuMenu= "Le &Nettoyeur (de polygones)"
    iface.addPluginToVectorMenu(self.nomDuMenu, self.clean)
    iface.addPluginToVectorMenu(self.nomDuMenu, self.cut)

  def unload(self): # Remove the plugin menu item and icon
    iface.removeToolBarIcon(self.clean)
    iface.removeToolBarIcon(self.cut)
    iface.removePluginVectorMenu(self.nomDuMenu, self.clean)
    iface.removePluginVectorMenu(self.nomDuMenu, self.cut)

  def dialogMakeValid(self):
    win= iface.mainWindow()
    layer= iface.activeLayer()
    if not layer or layer.type()!=QgsMapLayer.VectorLayer:
      QMessageBox.warning(win, u"Attention", u"Il faut d'abord sélectionner la couche vecteur à nettoyer")
      return
    if layer.geometryType()!=QgsWkbTypes.PolygonGeometry:
      QMessageBox.warning(win, u"Désolé", u"Cette extension ne traite que les couches de polygones.")
      return
    self.fenMV= dialogMakeValid(layer)
    self.fenMV.show()
  
  def dialogOverlapping(self):
    win= iface.mainWindow()
    layer= iface.activeLayer()
    if not layer or layer.type()!=QgsMapLayer.VectorLayer:
      QMessageBox.warning(win, u"Attention", u"Il faut d'abord sélectionner la couche vecteur à nettoyer")
      return
    if layer.geometryType()!=QgsWkbTypes.PolygonGeometry:
      QMessageBox.warning(win, u"Désolé", u"Cette extension ne traite que les couches de polygones.")
      return
    self.fen= dialogOverlapping(layer)
    self.fen.show()



class dialogMakeValid(QDialog):
  def __init__(self, layer, parent=iface.mainWindow(), showAll=True):
    flags= Qt.WindowTitleHint | Qt.Tool | Qt.WindowCloseButtonHint | Qt.WindowStaysOnTopHint
    QDialog.__init__(self, parent, flags)
    self.setGeometry(parent.geometry().x()+30, parent.geometry().y()+10, 500, 100)
    self.setWindowTitle('Corriger les géométries non valides' )
    #shortcut= QShortcut(QKeySequence(Qt.Key_Escape),self) ;    shortcut.setAutoRepeat(False) ## Disable Esc key
    
    self.layer= layer
    self.afficher= showAll # To display layers produced or not (in this case return cleaned layer)
    self.continuer= False  # If True, this dialog can't be closed
    
    Layout1= QGridLayout(self)
    li= 0
    info1= QLabel(self)
    info1.setText( "<center><h3>Traitement de la couche <strong>"+ self.layer.name() +"</strong></h3></center>"
     "Corriger les géométries non valides ( méthodes 'MakeValid' ou tampon(0) )." )
    Layout1.addWidget( info1, li, 0, 1, 2 )
    #li+=1    separ= QLabel(self)    separ.setText("<center><hr></center>")    Layout1.addWidget( separ, li, 0, 1, 2 )
    li+=1
    self.infoTime= QLabel("Cela peut durer quelques minutes...", self)
    self.infoTime.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
    Layout1.addWidget( self.infoTime, li, 0, 1, 1 )
    self.bClean= QPushButton("Corriger les géometries")
    #bClean.setToolTip("")
    self.bClean.clicked.connect(self.corriger) # Le signal clicked envoit l'argument False
    Layout1.addWidget(self.bClean, li, 1, 1, 1 )
    
    li+=1
    self.barreClean= QProgressBar(self)
    self.barreClean.setMinimum(0)
    self.barreClean.setMaximum(100)
    self.barreClean.setTextVisible(False)
    Layout1.addWidget( self.barreClean, li, 0, 1, 2 )
    
    li+=1
    self.resuClean= QLabel(" ", self) #self.resuClean.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
    Layout1.addWidget( self.resuClean, li, 0, 1, 2 )


  def corriger(self): ###  Corriger les erreurs topologiques
    ## Si fonction appelee par  trouver ou  couper --> afficher==False
    self.continuer= True # May be changed by self.bClean button
    win= iface.mainWindow()
    layer= self.layer
    self.bClean.setText(u"Arrêter le traitement ")
    self.bClean.clicked.disconnect(self.corriger)
    self.bClean.clicked.connect(self.stopperTraitement)
    
    msgB= QgsMessageBarItem( "Patienter pendant la correction des géométries de la couche...", 0 )
    messageBar= iface.messageBar()
    """if self.afficher: # Si fonction appelee depuis dialogMakeValid
        messageBar= iface.messageBar()
      else: # Si fonction appelee depuis "self.trouver" ou "self.couper"
        messageBar= QgsMessageBar( self )
        # Positionner la barre en haut à gauche de la zone des détails ( self.detailFiche ) :
        messageBar.setSizePolicy( QSizePolicy.Minimum, QSizePolicy.Fixed )
        messageBar.setGeometry( 0, 0, self.width(), 36) #"""
    messageBar.pushItem( msgB )
    QApplication.instance().processEvents() # Pour afficher messageBar immediatement
    debut=time.time()
    
    if self.continuer: # New layers definitions :
      nomChamp= 'zz_qgis_id_zz'
      nomFinale= "corrigee"
      finale= QgsVectorLayer("Polygon?crs=EPSG:2154", nomFinale, "memory")
      finale.setCrs(layer.crs()) #change memorylayer crs to layer crs
      finale.setProviderEncoding( layer.dataProvider().encoding() )
      finalePr= finale.dataProvider()
      finale.startEditing()
      finalePr.addAttributes( layer.fields().toList() )
      finale.commitChanges()
      
      nomBad= "geomNonValides" # Couche temporaire qui regroupera toutes les geom non valides
      bad= QgsVectorLayer("Polygon?crs=EPSG:2154", nomBad, "memory")
      bad.setCrs(layer.crs()) #change memorylayer crs to layer crs
      bad.setProviderEncoding( layer.dataProvider().encoding() )
      badPr= bad.dataProvider()
      bad.startEditing()
      champs= QgsFields( layer.fields() )
      champs.append( QgsField('zCauseDestrucz',QVariant.Int,'Integer',8) )
      badPr.addAttributes( champs.toList() )
      bad.commitChanges()
      
      nomSansGeom= "entitesSansGeometrie" # Couche temporaire qui regroupera toutes les entites sans geometrie
      sansGeom= QgsVectorLayer("Polygon?crs=EPSG:2154", nomSansGeom, "memory")
      sansGeom.setCrs(layer.crs()) #change memorylayer crs to layer crs
      sansGeom.setProviderEncoding( layer.dataProvider().encoding() )
      sansGeomPr= sansGeom.dataProvider()
      sansGeom.startEditing()
      sansGeomPr.addAttributes( layer.fields().toList() )
      sansGeom.commitChanges()
      
      nomGeomDetruit= "geometriesDetruites" # Couche temp qui regroupe toutes les entites dont la geometrie a ete detruite par la correction
      geomDetruit= QgsVectorLayer("Polygon?crs=EPSG:2154", nomGeomDetruit, "memory")
      geomDetruit.setCrs(layer.crs()) #change memorylayer crs to layer crs
      geomDetruit.setProviderEncoding( layer.dataProvider().encoding() )
      geomDetruitPr= geomDetruit.dataProvider()
      geomDetruit.startEditing()
      champs= QgsFields( layer.fields() )
      champs.append( QgsField('zCauseDestrucz',QVariant.Int,'Integer',8) )
      geomDetruitPr.addAttributes( champs.toList() )
      geomDetruit.commitChanges()
    
    nb= layer.featureCount()
    count= 0
    progress= 1

    countTypes= {} # Compter les types de QgsWkbTypes::Type (apres makeValid) ou -1 si geom detruite par makeValid
    for i in range(-1,50): countTypes[i]= 0
    countTypesCorr= {} # Compter les types de QgsWkbTypes corriges
    for i in range(-1,50): countTypesCorr[i]= 0
    
    nbBad= 0 ; nbMakeValid= 0 ; nbBuffer= 0 ; nbLost= 0
    for f in layer.getFeatures(): ##########  Tester / corriger toutes les entites :
      count += 1
      if (count*100/nb)>=progress:
        self.barreClean.setValue( progress )
        QApplication.instance().processEvents()
        progress+=1
      if not self.continuer: break # self.continuer peut etre modifié par le bouton bClean
      #
      #if nbBad>100: break ###############
      geom= f.geometry()
      if not geom: # Si l'entité n'a pas de geom !
        newF= QgsFeature()
        newF.setAttributes(f.attributes()) #copy attributes from original feature
        sansGeomPr.addFeatures( [newF] )
        continue
      #
      if geom.isGeosValid(): # Si geometrie OK : copier l'entité dans "finale"
        newF= QgsFeature()
        newF.setAttributes(f.attributes()) #copy attributes from original feature
        newF.setGeometry( geom )
        finalePr.addFeatures( [newF] )
        continue
      #
      nbBad += 1
      #st_multi(st_simplify(st_multi(ST_CollectionExtract(castToGeometryCollection(ST_MakeValid(geometry)),3)),0))
      statut= 10 # statut>=10 == OK
      geom= geom.makeValid()
      if not geom:
        statut= 1
        result= -1
        countTypes[-1]= countTypes[-1] +1
        print( "geometry detruite par makeValid pour "+ str(f[0]) )
      else: # makeValid OK
        result= geom.wkbType()
        countTypes[result]= countTypes[result] +1
        #if result==QgsWkbTypes.MultiLineString:
        #if geom.type==QgsWkbTypes.PolygonGeometry:
        geom.convertGeometryCollectionToSubclass(QgsWkbTypes.PolygonGeometry)
        #collec= geom.asGeometryCollection()      #geom= QgsGeometry.collectGeometry(collec)
        if not geom:
          statut= 2
          #print( "Geom detruite par convertGeometryCollectionToSubclass pour "+ str(f[0]) )
          #print( "  type apres makeValid :"+ str(result) )
        else: # convertGeometryCollectionToSubclass OK
          geom.convertToMultiType()
          if not geom:
            statut= 3  # or geom.isEmpty()
            print( "geom detruite par 1er convertToMultiType pour "+ str(f[0]) )
          else:
            geom= geom.simplify(0)
            if not geom:
              statut= 4
              print( "geom detruite par convertToMultiType pour "+ str(f[0]) )
            else:
              geom.convertToMultiType()
              if not geom:
                statut= 5
                print( "geom detruite par 2e convertToMultiType pour "+ str(f[0]) )
              else:
                nbMakeValid += 1
                countTypesCorr[result] += 1
      #
      if statut<10: # Essayer de corriger par buffer(0)
        #print( "Methode buffer pour "+ str(f[0]) +" -- type : "+ str(result) )
        geom= f.geometry().buffer(0,3) #(float(0),3,0,0,2)
        if geom: # and not geom.isNull():
          statut= 10
          nbBuffer += 1
          countTypesCorr[result] += 1
      #
      if statut==10: # Si la geom n'a pas été détruite pendant la correction
        newF= QgsFeature()
        newF.setAttributes(f.attributes()) #copy attributes from original feature
        newF.setGeometry( geom )
        finalePr.addFeatures( [newF] )
      #
      else: # Si geometrie détruite: copier l'entité dans la couche "geomDetruit" :
        nbLost += 1
        newF= QgsFeature( champs )
        aa= f.attributes()
        aa.append( statut )
        newF.setAttributes( aa )
        #print f.id(), newF.attributes()
        newF.setGeometry( f.geometry() ) #newF.setAttributes( f.attributes() )
        geomDetruitPr.addFeatures( [newF] )
      #
      # Geometrie Not valid : copier l'entité dans la couche "bad"
      newF= QgsFeature( champs )
      aa= f.attributes()
      aa.append( statut )
      newF.setAttributes( aa )
      newF.setGeometry( f.geometry() ) #newF.setAttributes( f.attributes() )
      badPr.addFeatures( [newF] )
    
    
    messageBar.popWidget( msgB ) # iface.messageBar().popWidget( msg )
    if not self.continuer: ## If treatment INTERRUPTED
      if not self.afficher:  return None ## If treatment called by "trouver" or "couper"
      self.resuClean.setText("<center><b>Correction interrompue</b></center>" )
      self.bClean.setText("Redémarrer la correction")
      self.bClean.clicked.connect( self.corriger )
      return
    self.continuer= False  # If True, this dialog can't be closed
    
    self.infoTime.setText("<center><b>---- FIN ----</b><br>durée : %.1f sec</center>"% (time.time() - debut) )
    
    if nbBad==0: # NO invalid geom :
      if self.afficher:
        self.resuClean.setText("Il n'y avait aucune erreur de géométrie dans la couche <b>"+layer.name()+"</b>")
        #QMessageBox.about(win, "Traitement terminé","GEOS n'a pas trouvé d'erreur de géométrie dans la couche <u>"+layer.name()+u"</u>" )
        self.bClean.setText("Fermer")
        self.bClean.clicked.connect( lambda: self.hide() )
      return layer
    
    print( "Compter les types de QgsWkbTypes::Type (apres makeValid) ou -1 si geom detruite par makeValid :" )
    for k,v in countTypes.items():
      if k in geometryTypes: typ= geometryTypes[k]
      else: typ= str(k)
      if v>0: print( "Type "+ typ +" : "+ str(v) +"  --  nb corriges: "+ str(countTypesCorr[k]) )
    
    if nbLost>0:
      #print( "La correction a detruit des geometries. Couche des entites sans geometrie: "+ nomGeomDetruit)
      QgsProject.instance().addMapLayer(geomDetruit)
      #if self.afficher:
      #  QMessageBox.about(win, u"Attention",
      #  u'La correction a "détruit" des géometries.<br>Couche des entités sans géometrie: <u>'+ nomGeomDetruit +u'</u>' )
      msg= QgsMessageBarItem( 'La correction des géometries en a "détruit" certaines. Voir les entités dans <b>'+ nomGeomDetruit +'</b>', 1, 10 )
      messageBar.pushItem( msg ) # iface.messageBar().pushItem( msg )
    
    if not self.afficher:  return finale ## Si fonction appelee depuis trouver ou couper
    
    QgsProject.instance().addMapLayer(bad)
    QgsProject.instance().addMapLayer(finale)
    #QMessageBox.about(win, u"Traitement terminé",  u"La couche corrigée : <b>"+nomFinale+u"</b><br><br>Retrouvez les géométries non valides (avant correction) dans : <u>"+nomBad+u"</u>" )
    #bad.reload()
    #finale.reload()
    iface.mapCanvas().clearCache()
    iface.mapCanvas().refresh()
    result= ""
    if nbMakeValid>0: result+= "Nombre de géometries corrigées par la méthode MakeValid : %d<br>"% nbMakeValid
    if nbBuffer>0: result+= "Nombre de géometries corrigées par la méthode tampon(0) : %d<br>"% nbBuffer
    if nbLost>0:
      result+= "Nombre de géometries détruites (polygones sans surface) : %d"% nbLost
      result+= "&nbsp;&nbsp;&nbsp; (voir la couche <b>"+ nomGeomDetruit +"</b>)<br>"
    self.resuClean.setText(result)
    self.barreClean.setValue( 100 )
    self.bClean.setText("Fermer")
    self.bClean.clicked.connect( lambda: self.hide() )
    
    if sansGeom.featureCount()>0:
      print("Il y a des entites sans geometrie. Voir la couche "+ nomSansGeom)
      QgsProject.instance().addMapLayer(sansGeom)
      if self.afficher:
        QMessageBox.about(win, u"Attention",
        u"Il y a des entités sans géometrie. Voir la couche <u>"+ nomSansGeom +u"</u>" )


  def stopperTraitement(self):
    self.continuer= False

  def reject(self):
    if self.continuer:  return # If True, this dialog can't be closed
    super(dialogMakeValid, self).reject()




class dialogOverlapping(QDialog):
  def __init__(self, layer):
    win= iface.mainWindow()
    flags= Qt.WindowTitleHint | Qt.Tool | Qt.WindowCloseButtonHint
    QDialog.__init__(self, win, flags)
    #shortcut= QShortcut(QKeySequence(Qt.Key_Escape),self); shortcut.setAutoRepeat(False) # Disable Esc key
    self.layer= layer
    self.continuer= False  # If True, this dialog can't be closed
    self.coucheCorrigee= None # Indique la couche corrigée si la couche d'origine a deja ete traitee (ex.: apres une recherche de superpositions )
    
    self.setGeometry(win.geometry().x()+50,win.geometry().y()+30,700,100)
    self.setWindowTitle(u'Recherche / Nettoyage des superpositions de : "'+ layer.name() +'"' )
    Layout1= QGridLayout(self)
    li= 0
    info1= QLabel(self)
    info1.setText( "<center><b>Traitement de la couche <u>"+ layer.name() +"</u></b></center>"
     "<br>Le nettoyage des superpositions coupe les surfaces des polygones qui chevauchent leurs voisins"
     " dans la même couche."
     "<br><br><b>Attention :</b> ce nettoyage va couper les intersections minuscules mais aussi les grandes."
     "<br>&nbsp; Quand 2 objets se superposent, il ne sait pas lequel est mal numérisé !"
     "<br><br><b>Recommandation :</b> commencer par <u>inspecter la couche</u> (1er onglet),"
     "<br>&nbsp; puis analyser les chevauchements importants et les traiter manuellement,"
     "<br>&nbsp;&nbsp;&nbsp; enfin lancer le <u>Nettoyage des superpositions</u> (2è onglet)." )
    Layout1.addWidget( info1, li, 0, 1, 2 )
    
    li+=1
    tabs= QTabWidget(self)
    Layout1.addWidget( tabs, li, 0, 1, 2 )
    
    tabInspect= QWidget() ##############  Tab 1
    tabs.addTab(tabInspect,"Inspecter la couche")
    LayoutInspect= QGridLayout(tabInspect)
    liInspect= 0
    infoTrouv= QLabel( u"<b>Rechercher les zones de chevauchements :</b>"
      u"<br>&nbsp;&nbsp;&nbsp;&nbsp; cela peut durer quelques minutes...", self)
    #  u"<br>&nbsp;&nbsp;&nbsp; Cela peut prendre quelques minutes..."
    LayoutInspect.addWidget( infoTrouv, liInspect, 0, 1, 1 )
    self.bTrouv= QPushButton(u"Chercher les superpositions")
    self.bTrouv.clicked.connect(self.trouver)
    LayoutInspect.addWidget(self.bTrouv, liInspect, 1, 1, 1 )
    liInspect+=1
    infoHoles= QLabel( '<b>Rechercher les "trous" dans les polygones<br>&nbsp;&nbsp; ou entre eux :</b>'
      "<br>&nbsp;&nbsp;&nbsp;&nbsp; cela peut durer quelques minutes...", self)
    LayoutInspect.addWidget( infoHoles, liInspect, 0, 1, 1 )
    self.bHoles= QPushButton(u"Chercher les trous")
    self.bHoles.clicked.connect(self.searchHoles)
    LayoutInspect.addWidget(self.bHoles, liInspect, 1, 1, 1 )
    
    
    tabClean= QWidget()  ##############  Tab 2
    tabs.addTab(tabClean,"Nettoyer la couche")
    LayoutClean= QGridLayout(tabClean)
    liClean= 0
    info2= QLabel(self)
    info2.setText( "<b>Nettoyage des superpositions :</b>"
     "<br>&nbsp;&nbsp;&nbsp;&nbsp;les polygones nettoyés seront affichés dans une couche temporaire."
     "<br><br>Vous pouvez définir la priorité (quel objet coupe et quel objet est coupé) selon un attribut :<br>"
     "&nbsp;1) Les polygones de cette couche seront triés selon la valeur de cet attribut.<br>"
     "&nbsp;2) Ceux qui sont classés les premiers vont couper ceux qui sont classés les derniers." )
    # u"<br>&nbsp;&nbsp; à partir de la couche <u>"+ layer.name() +"</u>"
    # u"<br><b>&nbsp;&nbsp;&nbsp; où tous les chevauchements de polygones auront été éliminés</b>."
    #u"<br>&nbsp;&nbsp;Un oeil humain devrait <b>d'abord contrôler la couche</b>, analyser les chevauchements importants"
    LayoutClean.addWidget( info2, liClean, 0, 1, 2 )
    liClean+=1
    """choix= QLabel(self)
      choix.setText(u"           Ordre de découpage selon l'attribut :")
      LayoutClean.addWidget( choix, 7, 0, 1, 1 ) """
    self.lAttribut= QComboBox(self)
    self.lAttribut.addItem(u"   ---  Aucune priorité (découpage au hasard)  ---   ", "")
    for f in layer.fields():
      self.lAttribut.addItem( f.name(), f.name() )
    LayoutClean.addWidget( self.lAttribut, liClean, 0, 1, 1 ) # 7, 1, 1, 1 )
    #self.lAttribut.setItemText(0, _translate("Dialog", "-- COMMUNE --", None))
    #self.lTri= QLineEdit('zonage_fut', self )
    #LayoutClean.addWidget( self.lTri, 1, 1, 1, 1 )
    self.cDecroissant= QCheckBox("Tri décroissant (valeurs élevées en 1er)", self)
    # self.cCroissant.setCheckState(Qt.Checked)
    LayoutClean.addWidget( self.cDecroissant, liClean, 1, 1, 1 )
    
    liClean+=1
    info4= QLabel(self)
    info4.setText( "OPTION : combler les lacunes (trous) dans les polygones ou entre eux :" )
    #info4.setText( u"Définir la taille minimale des trous à conserver (les trous + petits seront comblés) :" )
    info4.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    LayoutClean.addWidget( info4, liClean, 0, 1, 1 )
    self.lComblerTrous= QComboBox(self)
    self.lComblerTrous.addItem("Ne PAS combler les trous", "aucun")
    self.lComblerTrous.addItem("Trous + petits que cette surface en m²", "m2")
    self.lComblerTrous.addItem("Trous + petits que cette surface en km²", "km2")
    self.lComblerTrous.addItem("Combler TOUS les trous", "tous")
    LayoutClean.addWidget( self.lComblerTrous, liClean, 1, 1, 1 )
    
    liClean+=1
    infoTrous2= QLabel(self)
    infoTrous2.setText( u"Les trous + petits que cette surface (choisir unités ci-dessus) seront comblés :" )
    infoTrous2.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    LayoutClean.addWidget( infoTrous2, liClean, 0, 1, 1 )
    #self.toler= QLineEdit( '2', self )  #self.toler.setMinimumSize(200,28)
    #self.toler.setSizePolicy( QSizePolicy.Expanding, QSizePolicy.Fixed )
    self.toler= QDoubleSpinBox( self )
    #self.toler.setMaximumWidth(110)
    self.toler.setMinimum(0.001)
    self.toler.setMaximum(100000)
    self.toler.setValue(10)
    self.toler.setSuffix("  (unité déf. ci-dessus)")
    LayoutClean.addWidget(self.toler, liClean, 1, 1, 1 )
    
    liClean+=1
    infoTopo= QLabel(self)
    infoTopo.setText("<b>OPTION</b> : rendre la couche parfaitement topologique (<b>c'est plus lent</b>) :" )
    infoTopo.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    LayoutClean.addWidget( infoTopo, liClean, 0, 1, 1 )
    self.choixTopo= QCheckBox("(conseillé pour combler les trous)", self)
    LayoutClean.addWidget( self.choixTopo, liClean, 1, 1, 1 )
    
    liClean+=1
    infoClean= QLabel("Cela peut durer quelques minutes...", self)
    infoClean.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
    LayoutClean.addWidget( infoClean, liClean, 0, 1, 1 )
    self.bStop= QPushButton("Nettoyer les superpositions")
    self.bStop.clicked.connect(self.couper)
    #bStop.setToolTip(self.tr("<p>Save changes<br />then update menus.</p>")+ "<br /><br /><br />")
    LayoutClean.addWidget(self.bStop, liClean, 1, 1, 1 )
    """
      li+=1
      self.resuTopo= QLabel(self)
      self.resuTopo.setText("Ce traitement est très long...")
      self.resuTopo.setAlignment(Qt.AlignHCenter)
      Layout1.addWidget( self.resuTopo, li, 0, 1, 1 )
      self.bTopo= QPushButton("Rendre la couche topologique")
      self.bTopo.clicked.connect(self.coucheTopo)
      Layout1.addWidget(self.bTopo, li, 1, 1, 1 )
      li+=1
      separ= QLabel(self)
      separ.setText(u"<center><hr></center>")
      Layout1.addWidget( separ, li, 0, 1, 2 )
      li+=1
      info3= QLabel(self)
      info3.setText( u"<b>Nettoyage total : produit une couche topologique</b> (dans une couche temporaire)"
       u"<br>&nbsp;&nbsp;&nbsp; Supprime les superpositions et les trous et accroche les noeuds des objets voisins."
       u"<br>Vous pouvez définir la priorité ci-dessus." )
      Layout1.addWidget( info3, li, 0, 1, 2 )  #"""
    
    tabMakeValid= QWidget() ##############  Tab 3
    tabs.addTab(tabMakeValid,"Corriger les géométries")
    LayoutMakeValid= QGridLayout(tabMakeValid)
    self.bClean= QPushButton(u"Corriger les géométries non valides de la couche")
    self.bClean.clicked.connect(self.cleanGeom)
    LayoutMakeValid.addWidget(self.bClean, 0, 0, 1, 1 )
    
    ###############   Below tabs  ###############
    #li+=1    separ= QLabel(self)    separ.setText(u"<center><hr></center>")    Layout1.addWidget( separ, li, 0, 1, 2 )
    li+=1
    self.choixNet= QCheckBox(u"Corriger les géométries non valides (méthodes MakeValid + tampon 0) avant la recherche ou le nettoyage", self)
    self.choixNet.setCheckState(Qt.Checked)
    Layout1.addWidget( self.choixNet, li, 0, 1, 2 )
    li+=1
    self.barre= QProgressBar(self)
    self.barre.setMinimum(0)
    self.barre.setMaximum(100)
    self.barre.setTextVisible(False)
    Layout1.addWidget( self.barre, li, 0, 1, 2 )
    li+=1
    self.resu= QLabel(" ", self)
    self.resu.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
    Layout1.addWidget( self.resu, li, 0, 1, 2 )

  def cleanGeom(self): ### MakeValid geometries
    cleaner= dialogMakeValid(self.layer, self)
    cleaner.show()


  def trouver(self): ### Trouver les superpositions de polygones
    self.continuer= True
    self.bTrouv.setText("Arrêter la recherche")
    self.bTrouv.clicked.disconnect(self.trouver)
    self.bTrouv.clicked.connect(self.stopperTraitement)
    def finTraitement( text="<b>Traitement interrompu</b>", button="Redémarrer le traitement" ):
      self.resu.setText( text )
      self.bTrouv.setText( button )
      self.bTrouv.clicked.disconnect(self.stopperTraitement)
      self.bTrouv.clicked.connect( self.trouver )
    
    self.barre.setValue( 0 )
    debut=time.time()
    
    if self.choixNet.checkState()==Qt.Checked: # Commencer par corriger les geom non valides
      self.resu.setText("<b>&nbsp;&nbsp;&nbsp;Correction des géométries non valides en cours...</b>")
      QApplication.instance().processEvents()
      if self.coucheCorrigee: # Si la couche corrigee existe deja
        layer= self.coucheCorrigee
      else: # Si la couche corrigee n'existe pas encore
        cleaner= dialogMakeValid(self.layer, self, False)
        cleaner.show()
        layer= cleaner.corriger()
        cleaner.hide()
        if not layer: # If MakeValid was stopped
          finTraitement()
          return
        self.coucheCorrigee= layer
    else: layer= self.layer
    
    self.resu.setText("<b>&nbsp;&nbsp;&nbsp;Recherche des superpositions en cours...</b>")
    QApplication.instance().processEvents()
    
    cutName= "superpositions"
    cut= QgsVectorLayer("Polygon?crs=EPSG:4326", cutName, "memory")
    cut.setCrs(layer.crs()) #change memorylayer crs to layer crs
    cutpr= cut.dataProvider()
    cut.startEditing()
    surf= QgsField( "surface", QVariant.Double, "numeric", 20, 15) # Pour afficher la surface de superposition
    cutpr.addAttributes( [surf] ) # layer.fields().toList() )
    cut.commitChanges()
    
    nb= layer.featureCount()
    count= 0
    progress= 1
    totalModif= 0
    totalChevauch= 0
    liste= ''
    fait= [] #  Liste des id traites
    req1= QgsFeatureRequest()
    
    req2= QgsFeatureRequest()
    req2.setSubsetOfAttributes([]) # Aucun attribut
    for fsel in layer.getFeatures(req1): ## Search overlapping for each entity of layer
      fait.append(fsel.id())
      attributes= fsel.attributes()
      coupee= QgsFeature()
      #coupee.setAttributes(attributes) #copy attributes from original feature
    
      #if count==nb: break # Inutile de traiter le dernier feat car il a deja ete comparé à tous les autres
      count += 1
      if (count*100/nb)>=progress:
        self.barre.setValue( progress )  #count * 100 / nb )
        QApplication.instance().processEvents()
        progress+=1
      
      if not self.continuer: break # self.continuer peut etre modifié par le bouton bTrouv

      if not fsel.geometry():  continue  #check for geometry validity...experimental
      #geom= QgsGeometry( fsel.geometry() )
      
      req2.setFilterRect(fsel.geometry().boundingBox())
      for g in layer.getFeatures(req2):
        if g.id() in fait:  continue
        if not g.geometry():  continue
        #if g.geometry().touches(fsel.geometry()): continue # car intersects ci-dessous prend aussi celles qui "touchent"
        #if not g.geometry().intersects(fsel.geometry()): continue
        if not g.geometry().overlaps(fsel.geometry()): continue
        
        geomCut= fsel.geometry().intersection(g.geometry()) # geom.intersection(g.geometry())
        if not geomCut: continue
        totalChevauch += 1
        
        if geomCut.type()==QgsWkbTypes.UnknownGeometry:
          modif= 0
          for U in geomCut.asGeometryCollection():
            if U.type() != QgsWkbTypes.PolygonGeometry: continue
            modif +=1
            coupee.setGeometry( U )
            coupee.setAttributes([U.area()]) # Calculer la surface de superposition
            cutpr.addFeatures([coupee])
            #print "  Polygon in collection ; aire =", U.area()
          if modif>0: totalModif += 1
          continue
        
        if geomCut.type() != QgsWkbTypes.PolygonGeometry: continue
        aire= geomCut.area()
        #if aire==0: continue
        ###if aire < 0.01: continue
        coupee.setGeometry( geomCut )
        coupee.setAttributes([aire]) # Calculer la surface de superposition
        cutpr.addFeatures([coupee])
        totalModif += 1
    
    
    if not self.continuer:
      finTraitement()
      return
    self.continuer= False  # If True, this dialog can't be closed
    
    self.barre.setValue( 100 )
    self.bTrouv.setText("Fermer")
    self.bTrouv.clicked.connect( lambda: self.hide() )
    
    if totalModif==0:
      bilan= "<b>---- FIN ----</b><br>"
      bilan+= "La couche <b>%s</b> ne présente aucun chevauchement<br>" % self.layer.name()
      bilan+= "durée : %.1f sec"% (time.time() - debut)
      self.resu.setText( bilan )
      return
    
    bilan= "<b>---- FIN ----</b><br>"
    bilan+= 'Nombre total de chevauchements : %d<br>'% totalChevauch
    bilan+= '<b>Nombre de chevauchements visibles : %d</b><br>'% totalModif
    bilan+= 'Les zones de chevauchement sont affichées dans "%s"<br>'% cutName
    bilan+= "durée : %.1f sec"% (time.time() - debut)
    self.resu.setText(bilan)
    QgsProject.instance().addMapLayer(cut)

    iface.mapCanvas().clearCache()
    iface.mapCanvas().refresh()



  def searchHoles(self): ### Trouver les "trous" dans les polygones ou entre eux
    self.continuer= True
    self.bHoles.setText("Arrêter la recherche")
    self.bHoles.clicked.disconnect(self.searchHoles)
    self.bHoles.clicked.connect(self.stopperTraitement)
    def finTraitement( text="<b>Traitement interrompu</b>", button="Redémarrer le traitement" ):
      self.resu.setText( text )
      self.bHoles.setText( button )
      self.bHoles.clicked.disconnect(self.stopperTraitement)
      self.bHoles.clicked.connect( self.searchHoles )
      
    self.barre.setValue( 0 )
    debut=time.time()
    
    if self.choixNet.checkState()==Qt.Checked: # Commencer par corriger les geom non valides
      self.resu.setText("<b>&nbsp;&nbsp;&nbsp;Correction des géométries non valides en cours...</b>")
      QApplication.instance().processEvents()
      if self.coucheCorrigee: # Si la couche corrigee existe deja
        layer= self.coucheCorrigee
      else: # Si la couche corrigee n'existe pas encore
        cleaner= dialogMakeValid(self.layer, self, False)
        cleaner.show()
        layer= cleaner.corriger()
        cleaner.hide()
        if not layer: # If MakeValid was stopped
          finTraitement()
          return
        self.coucheCorrigee= layer
    else:  layer= self.layer
    
    self.resu.setText("<b>&nbsp;&nbsp;&nbsp;Recherche des trous en cours...</b>")
    QApplication.instance().processEvents()
    
    holeName= "trous"
    holeLayer= QgsVectorLayer("Polygon?crs=EPSG:4326", holeName, "memory")
    holeLayer.setCrs(layer.crs()) #change memorylayer crs to layer crs
    holepr= holeLayer.dataProvider()
    holeLayer.startEditing()
    surf= QgsField( "surface", QVariant.Double, "numeric", 20, 15) # Pour afficher la surface du trou
    holepr.addAttributes( [surf] )
    holeLayer.commitChanges()
    
    nb= layer.featureCount()
    count= 0
    progress= 1
    totalModif= 0
    totalChevauch= 0
    index= QgsSpatialIndex( QgsSpatialIndex.FlagStoreFeatureGeometries )
    listeLignes= [] #  Objets de layer convertis en lignes
    
    for fsel in layer.getFeatures(): ## Convertir objets de layer en lignes et les ajouter à listeLignes
      geom= fsel.geometry() #QgsGeometry( fsel.geometry() )
      if not geom or geom.isEmpty():  continue
      li= geom.convertToType(QgsWkbTypes.LineGeometry, True)
      if not li or li.isEmpty():  continue
      listeLignes.append( li )
      ret= index.addFeature(fsel)
    
    self.barre.setValue( 10 )
    self.resu.setText("Assembler les anneaux de toutes les entités de la couche...")
    QApplication.instance().processEvents()
    if not self.continuer: # self.continuer peut etre modifié par le bouton bStop
      finTraitement()
      return
    combi= QgsGeometry.unaryUnion( listeLignes ) ## C'est la somme de tous les périmètres des objets
    
    print("Apres unaryUnion( listeLignes ) :", time.time() - debut)
    self.barre.setValue( 40 )
    self.resu.setText("Reconvertir l'union des anneaux en petits polygones...")
    QApplication.instance().processEvents()
    if not self.continuer:
      finTraitement()
      return
    collec= QgsGeometry.polygonize( [combi] ) ## C'est la surface des objets découpée en petits polygones
    
    print("Apres polygonize :", time.time() - debut)
    self.barre.setValue( 41 )
    self.resu.setText("Trouver les trous : petit polygone n'appartenant à aucune entité...")
    QApplication.instance().processEvents()
    if not self.continuer:
      finTraitement()
      return
    
    for morceau in collec.asGeometryCollection(): ## Chercher à quelle id rattacher chaque petit polygone de collec
      point= morceau.pointOnSurface()
      ids= index.nearestNeighbor( point.asPoint(), 5, 0.000000000001 )
      if len(ids)>0:  continue ## If the pointOnSurface is within 1 or more features of layer
      # Sinon, morceau était un trou dans layer...
      new= QgsFeature()
      new.setAttributes( [morceau.area()] )
      new.setGeometry( morceau )
      holepr.addFeatures([new])
    
    print("Apres pointOnSurface + nearestNeighbor :", time.time() - debut)
    self.barre.setValue( 100 )
    self.bHoles.setText("Fermer")
    self.bHoles.clicked.disconnect(self.stopperTraitement)
    self.bHoles.clicked.connect( lambda: self.hide() )
    
    if holeLayer.featureCount()>0:
      QgsProject.instance().addMapLayer(holeLayer)
      #iface.mapCanvas().clearCache()
      iface.mapCanvas().refresh()
      #holeLayer.reload()
      bilan= "Retrouver les trous dans la couche  : <b>%s</b><br>"% holeName
    else:
      bilan= "La couche <b>%s</b> ne comporte aucun trou.<br>"% layer.name()
    
    self.resu.setText("<b>---- FIN ----</b><br>" +bilan +"durée : %.1f secondes"% (time.time()-debut) )



  def couper(self): ### Eliminer les superpositions de polygones 
    self.continuer= True
    self.bStop.setText(u"Arrêter le traitement")
    self.bStop.clicked.disconnect(self.couper)
    self.bStop.clicked.connect(self.stopperTraitement)
    
    if self.choixNet.checkState()==Qt.Checked: # Commencer par corriger les geom non valides
      self.resu.setText("<b>&nbsp;&nbsp;&nbsp;Correction des géométries non valides en cours...</b>")
      if self.coucheCorrigee: # Si la couche corrigee existe deja
        layer= self.coucheCorrigee
      else:
        cleaner= dialogMakeValid(self.layer, self, False)
        cleaner.show()
        layer= cleaner.corriger()
        cleaner.hide()
        if not layer: # If MakeValid was stopped
          self.finTraitement()
          return
        self.coucheCorrigee= layer
    else:  layer= self.layer
    
    self.resu.setText( u"<b>&nbsp;&nbsp;&nbsp;&nbsp;Correction des chevauchements en cours...</b>" )
    self.barre.setValue( 0 )
    QApplication.instance().processEvents()
    
    try:    tolerance= self.toler.value()   #tolerance= float( self.toler.text() )
    except: tolerance= 0 #QMessageBox.warning(win, u"Attention", u"Il faut indiquer une valeur")  #return
    choix= self.lComblerTrous.itemData( self.lComblerTrous.currentIndex() )
    if   choix=='tous' : tolerance= 0
    elif choix=='aucun': tolerance= -1
    elif choix=='km2'  : tolerance= tolerance * 1000000
    #elif choix=='m2'   : tolerance= tolerance
    
    if self.choixTopo.checkState()==Qt.Checked: # Utiliser l'autre methode
      self.coucheTopo(layer, tolerance)
      return
    debut=time.time()
    
    nomCouche= "nettoyee"
    resultat= QgsVectorLayer("Polygon?crs=EPSG:4326", nomCouche, "memory")
    resultat.setCrs(layer.crs()) #change memorylayer crs to layer crs
    resultat.setProviderEncoding( layer.dataProvider().encoding() )
    resultpr= resultat.dataProvider()
    resultat.startEditing()
    resultpr.addAttributes( layer.fields().toList() )
    resultat.commitChanges()  #print resultat.fields().toList()  #print resultpr.fields().toList()
    
    detruitName= u"polygones_detruits"
    detruit= QgsVectorLayer("Polygon?crs=EPSG:4326", detruitName, "memory")
    detruit.setCrs(layer.crs()) #change memorylayer crs to layer crs
    detruitpr= detruit.dataProvider()
    detruit.startEditing()
    detruitpr.addAttributes( layer.fields().toList() )
    detruit.commitChanges()
    
    nb= layer.featureCount() ; count= 0 ; progress= 1
    
    totalModif= 0 ; nbTrous= 0
    liste= ''
    fait= [] #  Liste des id traites
    faitGeom= {} # Les geom de id traites
    geomModif= {} # Les geom deja modifiees (indexées par leur id)
    listeAttrib= {} # Les attributs (indexés par leur id)
    req2= QgsFeatureRequest() # Pour lister les objets qui entourent le feat (de req1) à tester
    req2.setSubsetOfAttributes([]) # Aucun attribut
    req1= QgsFeatureRequest() # Liste tous les feat pour les tester
    #req1.setSubsetOfAttributes([]) # Aucun attribut
    tri= self.lAttribut.itemData( self.lAttribut.currentIndex() ) #self.lTri.text()
    if tri != '': # Trier selon l'attribut pour commencer par les 1ers et on va rogner leurs voisins
      if self.cDecroissant.checkState()==Qt.Checked: croissant= False
      else: croissant= True
      req1.setOrderBy( QgsFeatureRequest.OrderBy( [QgsFeatureRequest.OrderByClause(tri,croissant)] ) )
    
    for fsel in layer.getFeatures(req1): ## Pour chaque obj de layer, chercher+couper ses superpositions
      if fsel.id() in geomModif:
        geom= geomModif[fsel.id()]
        if not geom:  continue
      else: 
        geom= fsel.geometry() # QgsGeometry( fsel.geometry() )
        if not geom:  continue
        geomModif[fsel.id()]= geom
      #
      fait.append(fsel.id())
      attributes= fsel.attributes()
      listeAttrib[fsel.id()]= attributes
      #
      if count==nb: break # Inutile de traiter le dernier feat car il a deja ete comparé à tous les autres
      count += 1
      if (count*100/nb)>=progress:
        self.barre.setValue( progress )
        QApplication.instance().processEvents()
        progress+=1
      if not self.continuer: break # self.continuer peut etre modifié par le bouton bStop
      #
      voisins= {} # Objets qui intersectent fsel, indexés par leur id
      voisinsVus= [] # Voisinage deja vu mais pour gérer les parties du voisinsVu QUI SERAIENT DANS fsel
      req2.setFilterRect(fsel.geometry().boundingBox())
      for g in layer.getFeatures(req2): ## Collecter tous les voisins : les objets autour de fsel
        if g.id()==fsel.id(): continue
        if g.id() in fait and g.id() in geomModif:
          if tolerance>=0: voisinsVus.append( geomModif[g.id()] )
          continue
        if g.id() in geomModif:  geom2= geomModif[g.id()]
        else: geom2= g.geometry() # QgsGeometry( g.geometry() )
        if not geom2:  continue
        if tolerance<0 and geom2.touches(geom): continue # car intersects ci-dessous prend aussi celles qui "touchent"
        if not geom2.intersects(geom): continue
        voisins[g.id()]= geom2
      #
      if voisins=={}: continue # Geom inchangee car isolee
      #
      modif= 0
      fLignes= geom.convertToType( QgsWkbTypes.LineGeometry, True )
      lines= [fLignes] # Tous les obj convertis en lignes
      for id, g in voisins.items(): ## Transformer les voisins en lignes
        gLignes= g.convertToType( QgsWkbTypes.LineGeometry, True )
        if not gLignes or gLignes.isEmpty():  continue #gLignes "detruite" par le traitement
        lines.append(gLignes)
        modif += 1
      #
      combi= QgsGeometry.unaryUnion( lines ) ## C'est la somme de tous les périmètres de fsel et ses voisins
      collec= QgsGeometry.polygonize( [combi] ) ## C'est la surface de fsel et ses voisins découpée en petits polygones
      #
      newPoly= {}
      newPoly[fsel.id()]= []
      for id, g in voisins.items():  newPoly[id]= [] # Pour la liste des petits polygones à assembler
      listeTrous= []
      #
      for morceau in collec.asGeometryCollection(): ## Chercher à quelle id rattacher chaque petit polygone de collec
        point= morceau.pointOnSurface()
        if point.within(geom): # Si c'est une partie de fsel, on la rattache à fsel ET PAS aux voisins
          newPoly[fsel.id()].append(morceau)
          continue
        trouv= False
        for id, g in voisins.items(): # Rattacher chaque morceau à TOUS les voisins auxquels il appartient
          if point.within(g):
            newPoly[id].append(morceau)
            trouv= True
        if trouv or tolerance==-1: continue # Trous ignorés
        # Sinon, c'est un trou...
        for g in voisinsVus: # Est-ce que ce trou est une partie d'un voisin deja traité ?
          if point.within(g):
            trouv= True
            break
        if trouv: continue # Ce trou est une partie d'un voisin deja traité 
        nbTrous += 1
        """new= QgsFeature()
        new.setAttributes(attributes) #copy attributes from original feature
        new.setGeometry( morceau )
        detruitpr.addFeatures([new]) """
        if tolerance==0 or morceau.area() <= tolerance:
          listeTrous.append(morceau)
      #
      if listeTrous != []:
        geom= QgsGeometry.unaryUnion( newPoly[fsel.id()] ) # fsel APRES correction !
        for trou in listeTrous:
          if trou.touches( geom ): # S'il touche fsel (APRES correction)
            newPoly[fsel.id()].append(trou)
      #
      for id, listeG in newPoly.items(): ## Ré-assembler petits poly et anciens trous
        totalModif += 1
        if listeG==[]: # Si cet objet était completement within fsel
          geomModif[id]= None
          continue
        newGeom= QgsGeometry.unaryUnion( listeG )
        if newGeom:  geomModif[id]= newGeom
    
    
    for id, attr in listeAttrib.items(): ## Enregistrer dans la couche "nettoyee" ou "polygones_detruits"
      new= QgsFeature()
      new.setAttributes(attr)
      if geomModif[id] and not geomModif[id].isEmpty():
        new.setGeometry( geomModif[id] )
        resultpr.addFeatures([new])
      else:
        new= layer.getFeature(id)
        detruitpr.addFeatures([new])
    
    
    if not self.continuer: # Si le nettoyage a ete interrompu
      self.finTraitement()
      return
    self.continuer= False  # If True, this dialog can't be closed
    
    self.barre.setValue( 100 )
    self.bStop.setText("Fermer")
    self.bStop.clicked.connect( lambda: self.hide() )
    
    if totalModif==0:
      bilan= "<b>---- FIN ----</b> <br>La couche <b>%s</b> ne présente aucun chevauchement" % layer.name()
      bilan+= "<br> durée : %.1f sec"% (time.time()-debut)
      self.resu.setText( bilan )
      return
    
    QgsProject.instance().addMapLayer(resultat)
    bilan= "Les chevauchements ont été corrigés.<br>Nom de la couche sans superpositions : <b>%s</b><br>"% nomCouche
    if detruit.featureCount()>0:
      QgsProject.instance().addMapLayer(detruit)
      bilan += 'Les polygones détruits pendant le traitement sont dans "<u>'+detruitName+'</u>"<br>'
    if nbTrous>0: bilan += "nombre de trous comblés : %d<br>"% nbTrous
    self.resu.setText("<b>---- FIN ----</b><br>" +bilan +"durée : %.1f s"% (time.time()-debut) )
    QMessageBox.about( self, u"Résultats", bilan )
    resultat.reload()
    
    iface.mapCanvas().clearCache()
    iface.mapCanvas().refresh()



  def coucheTopo(self, layer, tolerance): ### Rendre la couche topologique : Tous les polygones -> lignes -> union -> polygonize -> within
    debut=time.time()
    nomCouche= layer.name() +"_nettoyee"
    resultat= QgsVectorLayer("Polygon?crs=EPSG:4326", nomCouche, "memory")
    resultat.setCrs(layer.crs()) #change memorylayer crs to layer crs
    resultat.setProviderEncoding( layer.dataProvider().encoding() )
    resultpr= resultat.dataProvider()
    resultat.startEditing()
    resultpr.addAttributes( layer.fields().toList() )
    resultat.commitChanges()
    #print resultat.fields().toList()  #print resultpr.fields().toList()
    
    detruitName= "polygones_detruits"
    detruit= QgsVectorLayer("Polygon?crs=EPSG:4326", detruitName, "memory")
    detruit.setCrs(layer.crs()) #change memorylayer crs to layer crs
    detruitpr= detruit.dataProvider()
    detruit.startEditing()
    detruitpr.addAttributes( layer.fields().toList() )
    detruit.commitChanges()
    
    req1= QgsFeatureRequest() # Liste tous les feat pour les tester
    tri= self.lAttribut.itemData( self.lAttribut.currentIndex() ) #self.lTri.text()
    if tri != '': # Trier selon l'attribut pour commencer par les 1ers et on va rogner leurs voisins
      if self.cDecroissant.checkState()==Qt.Checked: croissant= False
      else: croissant= True
      req1.setOrderBy( QgsFeatureRequest.OrderBy( [QgsFeatureRequest.OrderByClause(tri,croissant)] ) )
    
    self.barre.setValue( 2 )
    self.resu.setText("Extraire les anneaux des entités de la couche en les convertissant en lignes...")
    QApplication.instance().processEvents()
    
    index= QgsSpatialIndex( QgsSpatialIndex.FlagStoreFeatureGeometries )
    oldPoly= {} # Les objets existants
    newPoly= {} # Pour la liste des petits polygones à assembler
    listeLignes= [] #  Assemble tous les objets convetis en lignes
    listeAttrib= {} # Les attributs (indexés par leur id)
    for fsel in layer.getFeatures(req1): ## Convertir objets de layer en lignes et les ajouter à listeLignes
      geom= fsel.geometry() #QgsGeometry( fsel.geometry() )
      if not geom or geom.isEmpty():
        detruitpr.addFeatures([fsel])
        continue
      #if geom.removeDuplicateNodes(0.001) :  print("--- duplicateNodes")
      li= geom.convertToType(QgsWkbTypes.LineGeometry, True)
      if not li or li.isEmpty():
        detruitpr.addFeatures([fsel])
        continue
      index.addFeature(fsel)
      listeLignes.append( li )
      oldPoly[fsel.id()]= geom
      newPoly[fsel.id()]= [] # Initialiser la liste des petits polygones à assembler pour chaque objet de layer
      listeAttrib[fsel.id()]= fsel.attributes()
    
    self.barre.setValue( 10 )
    self.resu.setText("Assembler les anneaux de toutes les entités de la couche...")
    QApplication.instance().processEvents()
    if not self.continuer: # self.continuer peut etre modifié par le bouton bStop
      self.finTraitement()
      return
    combi= QgsGeometry.unaryUnion( listeLignes ) ## C'est la somme de tous les périmètres des objets
    print("Apres unaryUnion( listeLignes ) :", time.time() - debut)
    #if combi.removeDuplicateNodes() :  print("--- duplicateNodes: yes")
    #print("Apres removeDuplicateNodes :", time.time() - debut)
    
    self.barre.setValue( 60 )
    self.resu.setText("Reconvertir l'union des anneaux en petits polygones...")
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
    collec= QgsGeometry.polygonize( [combi] ) ## C'est la surface des objets découpée en petits polygones
    
    print("Apres polygonize :", time.time() - debut)
    self.barre.setValue( 61 )
    self.resu.setText("Trouver à quelle entité de la couche appartient chaque petit polygone...")
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
    
    nbOverlay= 0
    missingPieces= []
    req1.setNoAttributes() #setSubsetOfAttributes([]) # Aucun attribut
    nbHoles= 0
    for morceau in collec.asGeometryCollection(): ## Chercher à quelle id rattacher chaque petit polygone de collec
      point= morceau.pointOnSurface()
      ids= index.nearestNeighbor( point.asPoint(), 5, 0.000000000001 )
      if len(ids)==1: ## If the pointOnSurface is within 1 feature of layer
        newPoly[ids[0]].append(morceau)
        continue
      if len(ids)>1:  ## If the pointOnSurface is within multiple features of layer = zone of overlay
        nbOverlay += 1
        req1.setFilterFids( ids )
        for fsel in layer.getFeatures(req1):
          newPoly[fsel.id()].append(morceau)
          break ## Seul le 1er fsel est le bon
        continue
      """
        p= point.asPoint()
        trouv= False
        req1.setFilterRect( QgsRectangle(p.x()-0.001,p.y()-0.001,p.x()+0.001,p.y()+0.001) )
        for fsel in layer.getFeatures(req1): ## Convertir objets de layer en lignes et les ajouter à listeLignes
          if point.within(fsel.geometry()):
            newPoly[fsel.id()].append(morceau)
            trouv= True
            break
        if trouv: continue #"""
      ## Sinon, morceau était un trou dans layer...
      if tolerance==-1: continue # Trous ignorés
      ###if tolerance==0 or morceau.area() <= tolerance:  missingPieces.append(morceau)
      if tolerance>0 and morceau.area() > tolerance:  continue
      nbHoles += 1
      ids= index.nearestNeighbor( morceau, 5, 0.000000000001 )
      if len(ids)==1: ## If the trou is next to 1 feature of layer = hole in that feature
        newPoly[ids[0]].append(morceau)
        continue
      if len(ids)>1:  ## If the trou is next to multiple features of layer = gap between features
        req1.setFilterFids( ids )
        found= False
        for fsel in layer.getFeatures(req1): # getFeatures(req1) to take into account the orderby clause
          ###?? if trou.intersects( fsel.geometry() ): # S'il touche fsel (APRES correction)
          newPoly[fsel.id()].append(morceau)
          found= True
          break ## Seul le 1er fsel est le bon
        if found: continue
      missingPieces.append(morceau)
      print("1 trou n'a pas ete rattache !")
    print("Apres pointOnSurface + within :", time.time() - debut)
    
    self.barre.setValue(90)
    self.resu.setText('Chercher à rattacher chaque "trou" à une entité...')
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
      
    totalModif= 0
    geomModif= {} # Les geom modifiees (indexées par leur id)
    nbMissing= len(missingPieces)
    if nbMissing>0: index= QgsSpatialIndex()
    for id, listeG in newPoly.items(): ## Assembler les petits poly de chaque objets
      totalModif += 1
      if listeG==[]: continue # ça ne devrait pas arriver mais... 
      geomModif[id]= QgsGeometry.unaryUnion( listeG )
      if nbMissing>0: ret= index.addFeature( id, geomModif[id].boundingBox() )
    print("Apres Ré-assembler les objets :", time.time() - debut)
      
    listeModifier= {}
    for piece in missingPieces: ## Chercher à rattacher chaque missing Piece à un objet
      ids= index.nearestNeighbor( piece, 5, 0.000000000001 )
      if len(ids)==1: ## If the piece is next to 1 feature of geomModif = hole in that feature
        newPoly[ids[0]].append(piece)
        listeModifier[ids[0]]= True
        continue
      if len(ids)>1:  ## If the piece is next to multiple features of geomModif = gap between features
        req1.setFilterFids( ids )
        for fsel in layer.getFeatures(req1): # getFeatures(req1) to take into account the orderby clause
          if piece.touches( geomModif[fsel.id()] ): # S'il touche fsel (APRES correction)
            newPoly[fsel.id()].append(piece)
            listeModifier[fsel.id()]= True
            break ## Seul le 1er fsel est le bon
        continue
      print("1 piece n'a pas ete rattachee !")
    
    for id in listeModifier.keys(): ## Assembler (encore) les objets rattachés à des éventuelles missingPieces (étape précédente)
      geomModif[id]= QgsGeometry.unaryUnion( newPoly[id] )
    print("Apres Rattacher les Pieces :", time.time() - debut)
    print("nbHoles=%d ; missingPieces=%d"% (nbHoles,nbMissing) )
    
    self.barre.setValue( 95 )
    self.resu.setText('Enregistrer les nouveaux objets dans la couche "nettoyee"')
    QApplication.instance().processEvents()
    #for id, geom in geomModif.items(): ## Enregistrer dans la couche "nettoyee" ou "polygones_detruits" 
    for id, geom in oldPoly.items(): ## Enregistrer dans la couche "nettoyee" ou "polygones_detruits" 
      new= QgsFeature()
      new.setAttributes( listeAttrib[id] )
      if id in geomModif and geomModif[id] and not geomModif[id].isEmpty():
        new.setGeometry( geomModif[id] )
        resultpr.addFeatures([new])
      else:
        new.setGeometry( geom )
        detruitpr.addFeatures([new])
    
    self.continuer= False  # If True, this dialog can't be closed
    
    self.barre.setValue( 100 )
    self.bStop.setText("Fermer")
    self.bStop.clicked.disconnect(self.stopperTraitement)
    self.bStop.clicked.connect( lambda: self.hide() )
    QgsProject.instance().addMapLayer(resultat)
    iface.mapCanvas().clearCache()
    iface.mapCanvas().refresh()
    resultat.reload()
    
    if nbOverlay==0: bilan= 'Nom de la couche "propre" : <b>%s</b><br>'% nomCouche
    else:
      bilan = "Nom de la couche sans superpositions : <b>%s</b><br>"% nomCouche
      bilan+= "Tous les chevauchements ont été corrigés ( nb de zones de chevauchement : %d )<br>"% nbOverlay
    if nbHoles>0: bilan+= "nombre de trous comblés : %d<br>"% nbHoles
    if detruit.featureCount()>0:
      QgsProject.instance().addMapLayer(detruit)
      bilan += 'Les polygones détruits pendant le traitement sont dans "<b>'+detruitName+'</b>"<br>'
    self.resu.setText("<b>---- FIN ----</b><br>" +bilan +"durée : %.1f secondes"% (time.time()-debut) )
    QMessageBox.about( self, u"Résultats", bilan )



  def coucheTopoOLD(self, layer, tolerance): ### Rendre la couche topologique : Tous les polygones -> lignes -> union -> polygonize -> within
    debut=time.time()
    nomCouche= "nettoyee"
    resultat= QgsVectorLayer("Polygon?crs=EPSG:4326", nomCouche, "memory")
    resultat.setCrs(layer.crs()) #change memorylayer crs to layer crs
    resultat.setProviderEncoding( layer.dataProvider().encoding() )
    resultpr= resultat.dataProvider()
    resultat.startEditing()
    resultpr.addAttributes( layer.fields().toList() )
    resultat.commitChanges()
    #print resultat.fields().toList()  #print resultpr.fields().toList()
    
    detruitName= "polygones_detruits"
    detruit= QgsVectorLayer("Polygon?crs=EPSG:4326", detruitName, "memory")
    detruit.setCrs(layer.crs()) #change memorylayer crs to layer crs
    detruitpr= detruit.dataProvider()
    detruit.startEditing()
    detruitpr.addAttributes( layer.fields().toList() )
    detruit.commitChanges()
    
    req1= QgsFeatureRequest() # Liste tous les feat pour les tester
    tri= self.lAttribut.itemData( self.lAttribut.currentIndex() ) #self.lTri.text()
    if tri != '': # Trier selon l'attribut pour commencer par les 1ers et on va rogner leurs voisins
      if self.cDecroissant.checkState()==Qt.Checked: croissant= False
      else: croissant= True
      req1.setOrderBy( QgsFeatureRequest.OrderBy( [QgsFeatureRequest.OrderByClause(tri,croissant)] ) )
    
    self.resu.setText("Convertir les objets de la couche en lignes")
    QApplication.instance().processEvents()
    oldPoly= {} # Les objets existants
    newPoly= {} # Pour la liste des petits polygones à assembler
    listeLignes= [] #  Assemble tous les objets convetis en lignes
    listeAttrib= {} # Les attributs (indexés par leur id)
    for fsel in layer.getFeatures(req1): ## Convertir objets de layer en lignes et les ajouter à listeLignes
      geom= fsel.geometry() #QgsGeometry( fsel.geometry() )
      if not geom or geom.isEmpty():
        detruitpr.addFeatures([fsel])
        continue
      li= geom.convertToType(QgsWkbTypes.LineGeometry, True)
      if not li or li.isEmpty():
        detruitpr.addFeatures([fsel])
        continue
      listeLignes.append( li )
      oldPoly[fsel.id()]= geom
      newPoly[fsel.id()]= [] # Initialiser la liste des petits polygones à assembler pour chaque objet de layer
      listeAttrib[fsel.id()]= fsel.attributes()
    
    self.barre.setValue( 10 )
    self.resu.setText("Assembler toutes les lignes (unaryUnion)")
    QApplication.instance().processEvents()
    if not self.continuer: # self.continuer peut etre modifié par le bouton bStop
      self.finTraitement()
      return
    combi= QgsGeometry.unaryUnion( listeLignes ) ## C'est la somme de tous les périmètres des objets
    
    print("Apres unaryUnion( listeLignes ) :", time.time() - debut)
    self.barre.setValue( 40 )
    self.resu.setText("Convertir les lignes en petits polygones (polygonize)")
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
    collec= QgsGeometry.polygonize( [combi] ) ## C'est la surface des objets découpée en petits polygones
    
    print("Apres polygonize :", time.time() - debut)
    self.barre.setValue( 41 )
    self.resu.setText("A quelle entité appartient chaque petit poly (pointOnSurface+within)")
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
    listeTrous= []
    
    req1.setSubsetOfAttributes([]) # Aucun attribut
    for morceau in collec.asGeometryCollection(): ## Chercher à quelle id rattacher chaque petit polygone de collec
      point= morceau.pointOnSurface()
      p= point.asPoint()
      trouv= False
      #for id, geom in oldPoly.items(): # Rattacher chaque morceau à l'objet auxquel il appartient
      #  if point.within(geom):
      #    newPoly[id].append(morceau)
      req1.setFilterRect( QgsRectangle(p.x()-0.001,p.y()-0.001,p.x()+0.001,p.y()+0.001) )
      for fsel in layer.getFeatures(req1): ## Convertir objets de layer en lignes et les ajouter à listeLignes
        if point.within(fsel.geometry()):
          newPoly[fsel.id()].append(morceau)
          trouv= True
          break
      if trouv: continue
      # Sinon, morceau était un trou dans layer...
      if tolerance==-1: continue # Trous ignorés
      if tolerance==0 or morceau.area() <= tolerance:
        listeTrous.append(morceau)
    
    print("Apres pointOnSurface + within :", time.time() - debut)
    if tolerance==-1: self.barre.setValue(95)
    else:
      self.barre.setValue(80)
      self.resu.setText('Chercher à rattacher chaque "trou" à un objet')
    QApplication.instance().processEvents()
    if not self.continuer:
      self.finTraitement()
      return
      
    totalModif= 0
    geomModif= {} # Les geom modifiees (indexées par leur id)
    for id, listeG in newPoly.items(): ## Assembler les petits poly de chaque objets
      totalModif += 1
      if listeG==[]: continue # ça ne devrait pas arriver mais...
      geomModif[id]= QgsGeometry.unaryUnion( listeG )
    print("Apres Ré-assembler les objets :", time.time() - debut)
      
    listeModifier= {}
    for trou in listeTrous: ## Chercher à rattacher chaque "trou" à un objet
      for id, geom in geomModif.items(): # Rattacher chaque morceau à l'objet auxquel il appartient
        if trou.touches( geom ): # S'il touche fsel (APRES correction)
          newPoly[id].append(trou) #print( trou.area() )
          listeModifier[id]= True
          break
    
    for id in listeModifier.keys(): ## Assembler (encore) les objets rattachés à des trous (étape précédente)
      geomModif[id]= QgsGeometry.unaryUnion( newPoly[id] )
    print("Apres Rattacher les trous :", time.time() - debut)
    
    self.barre.setValue( 97 )
    self.resu.setText('Enregistrer les nouveaux objets dans la couche "nettoyee"')
    QApplication.instance().processEvents()
    #for id, geom in geomModif.items(): ## Enregistrer dans la couche "nettoyee" ou "polygones_detruits" 
    for id, geom in oldPoly.items(): ## Enregistrer dans la couche "nettoyee" ou "polygones_detruits" 
      new= QgsFeature()
      new.setAttributes( listeAttrib[id] )
      if id in geomModif and geomModif[id] and not geomModif[id].isEmpty():
        new.setGeometry( geomModif[id] )
        resultpr.addFeatures([new])
      else:
        new.setGeometry( geom )
        detruitpr.addFeatures([new])
    
    if not self.continuer: # Si le nettoyage a ete interrompu
      self.finTraitement()
      return
    self.continuer= False  # If True, this dialog can't be closed
    
    self.barre.setValue( 100 )
    self.bStop.setText("Fermer")
    self.bStop.clicked.disconnect(self.stopperTraitement)
    self.bStop.clicked.connect( lambda: self.hide() )
    
    if totalModif==0:
      bilan= "<center><b>---- FIN ----</b><br>durée : %.1f sec"% (time.time() - debut)
      bilan+= "<br>La couche <b>%s</b> ne présente aucun chevauchement</center>" % layer.name()
      self.resu.setText( bilan )
      return
    
    QgsProject.instance().addMapLayer(resultat)
    iface.mapCanvas().clearCache()
    iface.mapCanvas().refresh()
    resultat.reload()
    
    bilan = "Tous les chevauchements ont été corrigés.<br>"
    bilan+= "Nom de la couche sans superpositions : <b>%s</b><br>"% nomCouche
    if len(listeTrous)>0: bilan+= "<br>nombre de trous comblés : %d<br>"% len(listeTrous)
    if detruit.featureCount()>0:
      QgsProject.instance().addMapLayer(detruit)
      bilan += 'Les polygones détruits pendant le traitement sont dans "<b><br>'+detruitName+'</b>"'
    self.resu.setText("<b>---- FIN ----</b><br>" +bilan +"durée : %.1f secondes"% (time.time()-debut) )
    QMessageBox.about( self, u"Résultats", bilan )



  def stopperTraitement(self):
    self.continuer= False

  def finTraitement(self):
    self.resu.setText("<center><b>Traitement interrompu</b></center>" )
    self.bStop.setText("Redémarrer le traitement")
    self.bStop.clicked.disconnect(self.stopperTraitement)
    self.bStop.clicked.connect( self.couper )

  def reject(self):
    if self.continuer:  return # If True, this dialog can't be closed
    super(dialogOverlapping, self).reject()

