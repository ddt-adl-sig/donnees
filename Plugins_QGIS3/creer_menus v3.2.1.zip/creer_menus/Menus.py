# -*- coding: utf_8 -*-
from PyQt5.QtCore import QCoreApplication, QSettings, QLocale, QIODevice, QFile, QFileInfo, QDir, QTranslator, QObject, QUrl, QRegExp, QDateTime
from PyQt5.QtWidgets import QApplication, QAction, QMessageBox, QFileDialog, QDialog, QGridLayout, QHBoxLayout, QToolBar, QPushButton, QDockWidget, QTreeWidget
from PyQt5.QtGui import QIcon
from PyQt5 import QtXml
from PyQt5.QtWebKitWidgets import QWebView
from qgis.core import Qgis, QgsVectorLayer, QgsRasterLayer, QgsProject, QgsReadWriteContext, QgsLayout, QgsPrintLayout, QgsSettings, QgsApplication, QgsLayerDefinition
import qgis
from qgis.utils import iface
import imp, os, sys, importlib.util
from .editor.editorGui import xmlEditor

cePlugin= os.path.basename( os.path.dirname(__file__) )
version= qgis.utils.pluginMetadata(cePlugin,'version') ## Pour les changements, voir le fichier metadata.txt
#QgsMessageLog.logMessage(' plugin = ', 'Plugin_creer_menus')
#from builtins import range #from builtins import object #from __future__ import absolute_import

class monPlugin():
 def __init__(self, iface):
  self.iface= iface
  
  #try: ## Outil d'administration des QGIS locaux : pour ajouter des fonctionnalités
  """ Il faut corriger admin.py  pour QGIS3
  from .admin import configurer
  conf= configurer(self.iface)
  conf.activerPlugins()  # Activer certains plugins
  conf.ajouterWMS() # Ajouter une liste de serveurs WMS
  conf.ajouterWFS() # Ajouter une liste de serveurs WFS
  conf.paramQGIS() # Configurer Proxy et dépot, ajouter dossier SVG et activer plugins
  #except: pass ## Fin de l'outil d'admin
  #"""


 def tr(self, txt, disambiguation=None):
  return QCoreApplication.translate('Menus', txt, disambiguation)

 def initGui(self):
  self.path = os.path.abspath(os.path.dirname(__file__))
  # Traduction :
  overrideLocale = QSettings().value("locale/overrideFlag", False)
  localeFullName = QLocale.system().name() if not overrideLocale else QSettings().value("locale/userLocale", "")
  localePath = self.path + os.sep +"i18n"+ os.sep +"menus_" + localeFullName[0:2] + ".qm" #menus_fr.qm
  #if localeFullName[0:2] == "fr" : reload(sys) ; sys.setdefaultencoding('iso-8859-1')
  if not QFileInfo(localePath).exists(): # si pas de menus_fr.qm, on cherche menus_fr_FR.qm
    localePath = self.path + os.sep +"i18n"+ os.sep +"menus_" + localeFullName + ".qm"
  if QFileInfo(localePath).exists():
    self.translator = QTranslator()
    self.translator.load(localePath)
    QCoreApplication.installTranslator(self.translator)
  
  self.icons = self.path + os.sep + "icons" + os.sep
  # Ajouter un sous-menu dans le menu Extension avec une entrée "Aide" et une pour parametrer
  self.extensionMenuPerso = self.iface.pluginMenu().addMenu( QIcon(self.icons + "menus.png"), self.tr("&Create menus") )
  
  try: #pour ne pas afficher le bouton "Editer" si le module Qsci n'est pas installé
    from PyQt5.Qsci import QsciScintilla
    editAction = QAction( QIcon(self.icons + "menus.png"), self.tr("&Edit Menus definition file"), self.iface.mainWindow() )
    editAction.setStatusTip( self.tr("Choose Menus definition file") )
    editAction.triggered.connect(self.editeurMenus)
    self.extensionMenuPerso.addAction( editAction )
  except: pass

  paramAction = QAction( QIcon(self.icons + "menus.png"), self.tr("&Set Menus definition file"), self.iface.mainWindow() )
  paramAction.setStatusTip( self.tr("Choose Menus definition file") )
  paramAction.triggered.connect(self.fenetreParam)
  self.extensionMenuPerso.addAction( paramAction )
  
  self.boutonVersion= None ### Un bouton qui affiche la version de QGIS (ex. "3.4") pour distinguer la 3.4 de la 3.8
  
  aideAction = QAction( self.tr("&Help   (version %s)") % version, self.iface.mainWindow() )
  aideAction.setStatusTip( self.tr("User guide") )
  aideAction.triggered.connect(self.fenetreAide)
  self.extensionMenuPerso.addAction( aideAction )
  
  self.refqm= []  # liste des menus retournées par addMenu( monQmenu )
  self.nbmenus= 0
  self.affichage= self.iface.mainWindow().menuBar() # le menu Principal
  
  s = QSettings()
  
  app= QgsApplication.instance()
  settings= QgsSettings( s.format(), QSettings.UserScope, app.organizationName(), app.applicationName() )
  self.menusCommuns= settings.value("PluginCreerMenus/MenusCommuns", "")
  if QFile.exists(self.menusCommuns):
    dossier= os.path.abspath(os.path.dirname(self.menusCommuns)) # le dossier du fichier MenusCommuns
    self.dossierDuFichierXml= dossier # chemin pour trouver les fichiers relatifs à ce Xml dans traiterAction()
    self.lireMenusXml(self.menusCommuns)
  
  fichierMenus= s.value("PluginCreerMenus/fileMenus", "")
  # vide si 1er demarrage du plugin ; sinon voir si le fichier est présent :
  if fichierMenus=="" or not QFile.exists(fichierMenus):
    # Menus.xml ira à la base du profil Qgis (ex: %APPDATA%\QGIS\QGIS3\profiles\default\Menus.xml )
    iniFic= s.fileName()
    if QFile.exists(iniFic): #Si la config QGIS est stockee dans QGIS/QGIS3.ini
      menusPath= os.path.abspath(os.path.dirname(iniFic) + os.sep +'..')+ os.sep
    else: # Config dans base de registre
      menusPath= os.getenv('APPDATA') + os.sep +'QGIS3'+ os.sep
      rep= QDir(menusPath)
      if not rep.exists(): rep.mkpath(menusPath)
    fichierMenus = menusPath + "Menus.xml"
    s.setValue("PluginCreerMenus/fileMenus", fichierMenus) # enregistre le param du plugin
    if not QFile.exists(fichierMenus): # Copier le modele dans le profil utilisateur
      QFile.copy( self.path + os.sep + "Menus.xml.modele", fichierMenus )
  
  self.dossierDuFichierXml= os.path.abspath(os.path.dirname(fichierMenus)) # chemin du dossier vers le fichier xml
  if self.dossierDuFichierXml[-1]!=os.sep:  # Ajouter un / ou \ final
    self.dossierDuFichierXml= self.dossierDuFichierXml +os.sep
  self.lireMenusXml( fichierMenus )
 #Fin init Gui


 def voirBoutonVersionQGIS(self): ### Un bouton qui affiche la version de QGIS (ex. "3.4") pour distinguer la 3.4 de la 3.8
  qgisVer= Qgis.QGIS_VERSION.split('.')
  self.boutonVersion= QAction( qgisVer[0]+'.'+qgisVer[1], iface.mainWindow() )
  self.boutonVersion.setToolTip( "QGIS version "+ Qgis.QGIS_VERSION )
  self.boutonVersion.triggered.connect( lambda: iface.actionAbout().trigger() )
  self.toolBar= self.iface.pluginToolBar() # la barre d'outil des Extensions
  self.toolBar.addAction( self.boutonVersion )
  

 def editeurMenus(self):
  s = QSettings()
  fic = s.value("PluginCreerMenus/fileMenus", "")
  #editor = xmlEditor( self.iface.mainWindow(), fic, self.reload )
  editor = xmlEditor( None, fic, self.reload ) # parent=None permet de retrouver la fenetre dans la barre des taches
  try: #si le module Qsci n'est pas installé ça bug
    editor.resize(800,500)
    editor.setWindowTitle(self.tr("File: ")+ fic)
    editor.show()
    if editor.exec_():  editor.apply_changes()
  except:  pass
 #Fin editeur Menus
 
 def fenetreParam(self):
  msgBox = QMessageBox( self.iface.mainWindow() )
  msgBox.setWindowTitle( self.tr("Plugin: Create menus  (version %s)") % version )
  okButton = msgBox.addButton( self.tr("Close"), QMessageBox.RejectRole)
  
  PluginPath = os.path.normcase(os.path.normpath(os.path.realpath(os.path.dirname(__file__))))
  s = QSettings()
  fic = s.value("PluginCreerMenus/fileMenus", "")
  racine = os.path.abspath(os.path.dirname(fic))
  
  if not os.path.isfile( fic ): # premier démarrage de l'extension ou parametre incorrect
    msgBox.setText( self.tr("<strong>The file that contains the description of the menus is not defined !</strong>") )
    changeButton = msgBox.addButton( self.tr("Choose a file"), QMessageBox.AcceptRole)
    racine = os.path.normpath(PluginPath +"/../../..")
  else:
    msgBox.setText( "<strong>"+ self.tr("The file that contains the description of the menus is:") +"</strong><br>" + fic )
    changeButton = msgBox.addButton( self.tr("Choose another file"), QMessageBox.AcceptRole)

  modelButton = msgBox.addButton( self.tr("Create from template"), QMessageBox.AcceptRole)
  aideButton = msgBox.addButton( self.tr("Help"), QMessageBox.HelpRole)
  msgBox.setToolTip( """<p><font face="Helvetica, Arial, sans-serif">""" +
    self.tr("At its first start, the plugin copies a template file <strong>Menus.xml</strong> to the folder <u>USERPROFILE/.qgis2</u>. It adds a menu <u>Shortcuts</u> with a few examples of layers.</p> <p>This is the file to edit to create your menus. You can move that file to another folder then press button <u>Choose another file</u> to point the plugin to its new place.") +"</p><br /><br /><br />" )
  
  try: #pour ne pas afficher le bouton "Editer" si le module Qsci n'est pas installé
    from PyQt5.Qsci import QsciScintilla
    editButton = msgBox.addButton( self.tr("Edit"), QMessageBox.AcceptRole)
  except: editButton=0
  
  while True:
    msgBox.exec_()
    if msgBox.clickedButton() == changeButton:
      fileName, __ = QFileDialog.getOpenFileName(self.iface.mainWindow(), self.tr("Choose Menus file"), racine )
      if fileName=="": continue #si appuyé sur Annuler, ré-afficher msgBox
      s.setValue("PluginCreerMenus/fileMenus", fileName)
      msgBox.setText( self.tr("Menus definitions file is here:\n") + fileName )
      #u"Le fichier qui contient la description des menus se trouve ici :\n"
      self.unload()
      self.initGui()
      continue
    #
    elif msgBox.clickedButton() == modelButton: #copier le modele vers l'emplacement choisi
      fileName, __ = QFileDialog.getSaveFileName(self.iface.mainWindow(), u"Placer votre fichier (copie du modèle)",
        racine + os.sep + "Menus.xml" )
      if fileName=="": continue #si appuyé sur Annuler: ré-afficher msgBox
      if QFile.exists( fileName ): #s'il y a déjà un fichier, le supprimer :
        if not QFile.remove( fileName ): # si la suppression échoue :
          msgBox.setText( self.tr("Template copy failed.\n Please, choose another file name.") )
          #La copie du modèle a échoué.\n Merci de choisir un autre dossier ou un autre nom de fichier
          continue
      if not QFile.copy( PluginPath + os.sep + "Menus.xml.modele", fileName ): #si la copie a echoue
        msgBox.setText( self.tr("Template copy failed.\n Please, choose another folder.") )
        continue
      s.setValue("PluginCreerMenus/fileMenus", fileName)
      msgBox.setText( self.tr("Menus definitions file is here:\n") + fileName )
      self.unload()
      self.initGui()
      continue
    #
    elif msgBox.clickedButton() == editButton: # voir le XML
      editor = xmlEditor( self.iface.mainWindow(), fic, self.reload )
      try: #si le module Qsci n'est pas installé ça bug
        editor.resize(800,500)
        editor.setWindowTitle( self.tr("File : ") + fic)
        editor.show()
        if editor.exec_():  editor.apply_changes()
        break
      except:  pass
      continue
    #
    elif msgBox.clickedButton() == aideButton:
      self.fenetreAide(True)
      continue
    #
    else: break # bouton Fermer
    
    # verifier que fileName n'est pas dans le dossier du plugin (sera effacé par update) !!
    fileDir = os.path.normcase(os.path.normpath(os.path.realpath(os.path.dirname(fileName))))
    if PluginPath == fileDir:
      msgBox.setText( self.tr("Sorry but you can't put your file in the plugin folder.") )
      #Désolé, vous ne pouvez pas placer votre fichier dans le dossier du plugin.
      s.setValue("PluginCreerMenus/fileMenus", fic) #retour à la valeur precedente
    else: break
 #Fin fenetre Param

 def fenetreAide(self, modal=False):
  form = QDialog(self.iface.mainWindow())
  form.setWindowTitle( self.tr("Create Menus Guide") )
  #Mode d'emploi de l'extension : Créer ses propres menus
  fen= QWebView(form)  #QtWebKit.QWebView(form)
  Layout_1 = QGridLayout(form)
  Layout_1.setContentsMargins( 0, 0, 0, 0 )
  Layout_1.addWidget(fen, 0, 0, 1, 1)
  
  overrideLocale= QSettings().value("locale/overrideFlag", False)
  locale= QLocale.system().name() if not overrideLocale else QSettings().value("locale/userLocale", "")
  ficAide= self.path + os.sep +"help_"+ locale[0:2] +'.html' #help_fr.html
  if not QFileInfo(ficAide).exists(): # si pas de help_fr.qm, on cherche help_fr_FR.qm
    ficAide= self.path + os.sep +"help_"+ locale[0:2] +'.html'
  if not QFileInfo(ficAide).exists():
    ficAide= self.path + os.sep +'help.html'
  
  ficAide= 'file:///'+ ficAide.replace('\\','/')
  fen.load( QUrl(ficAide) ) #setUrl( QUrl(ficAide) )
  
  if modal : form.exec_() # pour le bouton Aide dans la fenetreParam
  else : form.show()
  #fen.reload()
 #Fin fenetre Aide

 def lireMenusXml(self, fichier):
  f = QFile( fichier )
  if not f.open(QIODevice.ReadOnly):  return
  doc= QtXml.QDomDocument()
  doc.setContent( f )
  root= doc.documentElement()
  rm= QRegExp("^[\n\r\t\s]*|[\n\r\t\s]*$") # les espaces, tab, retour ligne à supprimer au début et à la fin
  
  options= root.firstChildElement('options') # traiter les options
  if not options.isNull():
    elms= options.childNodes()
    for i in range(elms.length()): # parcourir toutes les options
      elm= elms.item(i).toElement()
      
      if elm.tagName()=="AjoutMenu":
        base= elm.text().strip(' \t\n\r')  #.remove(rm) # le texte de la balise sans les éventuels espaces avant et après
        if base== "Extension": self.affichage = self.iface.pluginMenu()
        elif base== "Couche": self.affichage = self.iface.layerMenu()
        elif base== "Database" : self.affichage = self.iface.databaseMenu()
        else: self.affichage= self.iface.mainWindow().menuBar() # dans le menu Principal de Qgis

      elif elm.tagName()=="MenusCommuns":
        MenusCommuns= elm.text().strip(' \t\n\r')  #.remove(rm) # le texte de la balise sans les éventuels espaces avant et après
        if not os.path.isfile(MenusCommuns): # tester avec un chemin relatif au fichier XML :
          MenusCommuns= self.dossierDuFichierXml + MenusCommuns
        if not os.path.isfile(MenusCommuns): continue
        if QFileInfo(MenusCommuns)==QFileInfo(self.menusCommuns): # Si on a déjà traité ce menusCommuns
          continue
        oldDossierDuFichierXml= self.dossierDuFichierXml # sauvegarde le chemin du dossier actuel
        dossier= os.path.abspath(os.path.dirname(MenusCommuns)) # le dossier du fichier MenusCommuns
        if dossier[-1:]!=os.sep:  dossier= dossier +os.sep # Ajouter un / ou \ final
        self.dossierDuFichierXml= dossier # chemin pour trouver les fichiers relatifs à ce Xml dans traiterAction()
        self.lireMenusXml(MenusCommuns)
        self.dossierDuFichierXml= oldDossierDuFichierXml # retablit le chemin

      elif elm.tagName()=="voirBoutonVersionQGIS": ### Un bouton qui affiche la version de QGIS (ex. "3.4") pour distinguer la 3.4 de la 3.8
        if not self.boutonVersion: self.voirBoutonVersionQGIS()

      elif elm.tagName()=="barre":
        self.afficherBarre( elm.attribute('nom'), elm.attribute('afficher') )

      elif elm.tagName()=="message":
        titre= elm.attribute('titre')
        txt  = elm.attribute('txt')
        type = elm.attribute('type')
        if   type=='warning': niv= Qgis.Warning
        elif type=='critique': niv= Qgis.Critical
        elif type=='succes': niv= Qgis.Success
        else:  niv= Qgis.Info
        duree= elm.attribute('duree')
        if duree.isdecimal():  duree= int(duree)
        else: duree= 5
        plus= elm.text().strip(' \t\n\r')  # Le texte de la balise sans les éventuels espaces avant et après
        if plus=="":
          self.iface.messageBar().pushMessage(titre, txt, level=niv, duration=duree)
        else:
          plus= plus.replace('\\n', '\n')          
          self.iface.messageBar().pushMessage(titre, txt, plus, level=niv, duration=duree)
  
  # une fois que les éventuelles options ont été traitées, il faut parcourir les menus :
  self.traiterMenu( root, self.affichage )
  f.close()
 #Fin lire MenusXml

 def afficherBarre(self, cle, val): #Merci à Christophe MASSE pour ce code :
  dictActions = {"BarreAide" : "mHelpToolBar", "BarreAttribut" : "mAttributesToolBar", "BarreCouches" : "mLayerToolBar", \
                 "BarreEtiquette" : "mLabelToolBar", "BarreFichier" : "mFileToolBar", "BarreGRASS" : "GRASS", \
                 "BarreNavig" : "mMapNavToolBar", "BarreNum" : "mDigitizeToolBar", u"BarreNumAvancée" : "mAdvancedDigitizeToolBar", \
                 "BarrePlugin" : "mPluginToolBar", "BarrePlugin" : "mPluginToolBar", "BarreRaster" : "mRasterToolBar", \
                 "BarreVecteur" :  "mVectorToolBar", "BarreBase" :  "mDatabaseToolBar", "BarreInternet" : "mWebToolBar"
                 }
  if cle not in dictActions : return
  else : param = dictActions[cle]
  Qbarre = self.iface.mainWindow().findChild(QToolBar,param)
  if not Qbarre : return
  if val.lower() == "n":  Qbarre.hide()
  elif val.lower() == "o":  Qbarre.show()
 #Fin afficher Barre

 def traiterMenu(self, elemXML, parent):
  """ fonction récursive qui parcourt chaque menu """
  elms = elemXML.childNodes()
  for i in range(elms.length()):
    elm = elms.item(i).toElement()
    
    if elm.tagName()=="menu":
      txtmenu= elm.attribute('nom')
      monQmenu= parent.addMenu(txtmenu)
      monQmenu.setToolTipsVisible(True) # depuis Qt 5.1
      self.refqm.append( monQmenu )
      self.traiterMenu( elm, monQmenu )
  
    elif elm.tagName()==u"séparateur": parent.addSeparator()
  
    elif elm.tagName()=="action": self.traiterAction(elm, parent)
 #Fin traiter Menu

 def traiterAction(self, elm, menu):
  titre= elm.attribute('nom')
  if titre=='':  return # l'action a été mal rédigée
  newaction= QAction( titre, self.iface.mainWindow() )
  rm= QRegExp("^[\n\r\t\s]*|[\n\r\t\s]*$") # les espaces, tab, retour ligne à supprimer au début et à la fin
  qml= None
  
  type= elm.attribute('type').lower()
  
  if type=='vecteur':
    val= elm.text().strip(' \t\n\r')   # .remove(rm) # le texte de la balise sans les éventuels espaces avant et après
    if not os.path.isfile(val): # si val not fichier, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not os.path.isfile(val): return
    tip= "Couche vecteur"
    newaction.setToolTip( val )
    fonction= self.afficheVecto
    nomfic= os.path.splitext( os.path.basename( val ) )[0] # le nom du fichier sans son extension
    # s'il existe un fichier de style pour cette couche (dans le meme dossier que le ficheir xml)
    if os.path.isfile(self.dossierDuFichierXml + nomfic +'.qml'):
      qml= self.dossierDuFichierXml + nomfic +'.qml'
    newaction.setIcon( QIcon(self.icons + "vecteur.png") )
    
  elif type=='qlr':
    val= elm.text().strip(' \t\n\r')   # .remove(rm) # le texte de la balise sans les éventuels espaces avant et après
    if not os.path.isfile(val): # si val not fichier, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not os.path.isfile(val): return
    tip= "Raccourci QGIS QLR"
    newaction.setToolTip( val )
    fonction= self.afficheQlr
    newaction.setIcon( QIcon(self.icons + "qlr.png") )
    
  elif type=='spatialite':
    val= elm.text().strip(' \t\n\r')  # le texte de la balise sans les éventuels espaces avant et après
    tip= "Couche spatialite"
    newaction.setToolTip( val )
    fonction= self.afficheSpatialite
    newaction.setIcon( QIcon(self.icons + "vecteur.png") )
    
  elif type=='postgres':
    val= elm.text().strip(' \t\n\r')  # le texte de la balise sans les éventuels espaces avant et après
    tip= "Couche PostgreSQL"
    newaction.setToolTip( tip )
    fonction = self.affichePostgres
    newaction.setIcon( QIcon(self.icons + "vecteur.png") )
    
  elif type=='raster':
    val= elm.text().strip(' \t\n\r') #.remove(rm)
    if not os.path.isfile(val): # si val not fichier, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not os.path.isfile(val): return
    tip= "Couche raster"
    newaction.setToolTip( val )
    fonction= self.afficheRaster
    nomfic= os.path.splitext( os.path.basename( val ) )[0] # le nom du fichier sans son extension
    # s'il existe un fichier de style pour cette couche (dans le meme dossier que le ficheir xml)
    if os.path.isfile(self.dossierDuFichierXml + nomfic +'.qml'):
      qml= self.dossierDuFichierXml + nomfic +'.qml'
    newaction.setIcon( QIcon(self.icons + "raster.png") )
    
  elif type=='wms':
    url= elm.firstChildElement('url')
    if url.isNull(): return
    val= url.text().strip(' \t\n\r')  #.remove(rm)
    couche= elm.firstChildElement('couche')
    if couche.isNull():  return
    val= val +"||"+ couche.text().strip(' \t\n\r')  #.remove(rm)
    format= elm.firstChildElement('format')
    if format.isNull():  val = val +"||image/png"
    else:  val= val +"||"+ format.text().strip(' \t\n\r')  #.remove(rm)
    scr= elm.firstChildElement('scr')
    if scr.isNull():  val = val +"||EPSG:2154"
    else:  val= val +"||"+ scr.text().strip(' \t\n\r')  #.remove(rm)
    style= elm.firstChildElement('style')
    if style.isNull():  val = val +"||"
    else:  val= val +"||"+ style.text().strip(' \t\n\r')
    
    tip = "Couche WMS"
    newaction.setToolTip( "Couche réseau WMS" )
    fonction= self.afficheWMS
    newaction.setIcon( QIcon(self.icons + "wms.png") )
    
  elif type=='wmts':
    url= elm.firstChildElement('url')
    if url.isNull(): val='' #return
    else: val= url.text().strip(' \t\n\r')  #.remove(rm)
    val= val.replace('=','%3D')
    val= val.replace('&','%26')
    couche= elm.firstChildElement('couche')
    if couche.isNull(): pass #return
    else: val= val +"||"+ couche.text().strip(' \t\n\r') #.remove(rm)
    format= elm.firstChildElement('format')
    if format.isNull():  val = val +"||image/png"
    else:  val= val +"||"+ format.text().strip(' \t\n\r')
    scr= elm.firstChildElement('scr')
    if scr.isNull():  val = val +"||EPSG:2154"
    else:  val= val +"||"+ scr.text().strip(' \t\n\r')
    
    tuiles= elm.firstChildElement('tuiles') #voir la colonne "Jeu de tuiles" dans QGIS > ajouter WM(T)S
    if tuiles.isNull(): pass #return
    else: val= val +"||"+ tuiles.text().strip(' \t\n\r')
    style= elm.firstChildElement('style')
    if style.isNull():  val= val +"||normal"
    else:  val= val +"||"+ style.text().strip(' \t\n\r')
    
    tip = "Couche WMTS"
    newaction.setToolTip( "Couche réseau WMTS" )
    fonction= self.afficheWMTS
    newaction.setIcon( QIcon(self.icons + "wms.png") )
    
  elif type=='wfs':
    url= elm.firstChildElement('url')
    if url.isNull():  return
    val= url.text().strip(' \t\n\r')  #.remove(rm)
    version= elm.firstChildElement('version') # version du protocol WFS
    if version.isNull():   val = val +"||1.0.0" # vaeur par defaut: 1.0.0
    else: val= val +"||"+ version.text().strip(' \t\n\r')  #.remove(rm)
    
    couche = elm.firstChildElement('couche') # nom de la couche
    if couche.isNull(): return
    val= val +"||"+ couche.text().strip(' \t\n\r')  #.remove(rm)
    
    scr= elm.firstChildElement('scr') # projection
    if scr.isNull():  val = val +"||EPSG:2154"
    else:  val= val +"||"+ scr.text().strip(' \t\n\r')  #.remove(rm)
    cache= elm.firstChildElement('cache') # determine si qgis telecharge toute la couche à l'ouverture
    if cache.isNull():  val= val +"||non" # valeur par defaut: non (telecharger en fonction des zooms)
    elif cache.text().strip(' \t\n\r')=='oui': val = val +"||oui" # telecharger toute la couche à l'ouverture
    else:  val= val +"||non"
    
    tip= "Couche WFS"
    newaction.setToolTip( "Couche réseau WFS" )
    fonction= self.afficheWFS
    newaction.setIcon( QIcon(self.icons + "wfs.png") )
    
  elif type=='projet': # ouvrir projet qgis .qgs
    val= elm.text().strip(' \t\n\r')  #
    if not QFile(val).exists(): # si val pas trouvé, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not QFile(val).exists(): return
    tip= "Ouvrir un projet"
    newaction.setToolTip( "Projet: "+ val )
    fonction= self.afficheProjet # remplace le travail en cours par ce projet
    newaction.setIcon( QIcon(self.icons + "proj.png") )
    
  elif type=='multi': # ajouter les couches d'un projet qgis
    val= elm.text().strip(' \t\n\r')  #
    if not QFile(val).exists(): # si val pas trouvé, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not QFile(val).exists(): return
    tip= u"Intégrer les couches d'un projet"
    newaction.setToolTip( tip )
    fonction= self.integrerProjet # intègre les couches du projet dans le travail en cours
    newaction.setIcon( QIcon(self.icons + "multi.png") )
    
  elif type=='web':
    val= elm.text().strip(' \t\n\r')  #
    tip= "Ouvrir une page web"
    newaction.setToolTip( tip )
    fonction= self.afficheWeb
    newaction.setIcon( QIcon(self.icons + "web.png") )
    
  elif type=='fichier':
    val= elm.text().strip(' \t\n\r')  #
    if not os.path.exists(val):  #ça permet d'indiquer un répertoire qui s'ouvrira avec l'explorateur Windows
      val= self.dossierDuFichierXml + val #si val not fichier, on teste avec le chemin relatif au fichier xml
    if not os.path.exists(val): return
    tip= "Ouvrir un fichier non QGIS"
    newaction.setToolTip( "Ouvrir "+ val )
    fonction= self.afficheAutreFichier
    newaction.setIcon( QIcon(self.icons + "file.png") )
    
  elif type=='python':
    elmArgs= elm.elementsByTagName('arg') # Liste des arguments pour le fichier Python
    if elmArgs.isEmpty():
      val= elm.text().strip(' \t\n\r')  # Ancienne ecriture de l'action
    else:
      val= elm.attribute('fichier')
      qml= [] # Liste des arguments à passer à la fonction
      for i in range(elmArgs.length()):
        argu= elmArgs.item(i).toElement()
        qml.append( argu.text() )
    
    if not os.path.isfile(val): # si val not fichier, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not os.path.isfile(val): return
    tip= "Exécuter du code Python"
    newaction.setToolTip( "Exécuter "+ val )
    fonction= self.execPython
    newaction.setIcon( QIcon(self.icons + "python.png") )
    
  elif type=='compo': #  Modele de composeur
    val= elm.text().strip(' \t\n\r')   # .remove(rm) # le texte de la balise sans les éventuels espaces avant et après
    if not os.path.isfile(val): # si val not fichier, on teste avec le chemin relatif au fichier xml
      val= self.dossierDuFichierXml + val
    if not os.path.isfile(val): return
    # L'attribut zoom indique s'il faut zoomer sur la carte du composeur ( 'oui' / 'yes' / 'non' / 'no') :
    zoom= elm.attribute('zoom').lower().strip(' \t\n\r')
    if zoom=='':  zoom= 'yes' # valeur par defaut
    qml= zoom  #newaction.setToolTip(zoom) 
    tip= u"Modèle de composeur"
    newaction.setToolTip( tip )
    fonction= self.openComposer
    newaction.setIcon( QIcon(self.icons + "compo.png") )
  
  else: return
  
  newaction.setStatusTip( tip )
  newaction.triggered.connect(lambda: fonction(titre,val,qml) )
  menu.addAction( newaction )
 #Fin traiter Action


 def afficheVecto(self, titre, chemin, qml):
  i= self.iface
  macouche= QgsVectorLayer(chemin, titre, 'ogr')
  if not macouche:  return
  i.mapCanvas().setRenderFlag( False )
  QgsProject.instance().addMapLayer(macouche)
  
  if qml: # le chemin d'un éventuel qml 
    try: macouche.loadNamedStyle( qml )
    except: pass
  
  pro= macouche.dataProvider()
  if chemin[-3:].lower()=='tab':
    if pro.encoding()==u'UTF-8':  pro.setEncoding("latin1")
  elif QFile.exists( chemin[0:-3] +'cpg' ):
    with open(chemin[0:-3] +'cpg','r') as f:
      enco= f.read()
      if enco!='':  pro.setEncoding(enco)
  
  i.mapCanvas().setRenderFlag( True )
 #Fin affiche Vecto

 def afficheQlr(self, titre, chemin, qml): # Merci à Frédéric MUZZOLON pour ce code :
  treeRoot= QgsProject.instance().layerTreeRoot()
  #self.iface.mapCanvas().setRenderFlag( False )
  msgBar= iface.messageBar()
  msg= msgBar.createMessage("Merci de patienter pendant l'ouverture du fichier")
  msgBar.pushItem(msg)
  #msgBar.pushMessage("Patientez pendant l'ouverture du fichier", level=Qgis.Info, duration=5 )
  QApplication.processEvents()
  QgsLayerDefinition.loadLayerDefinition(chemin, QgsProject.instance(), treeRoot)
  msgBar.popWidget(msg)
  #self.iface.mapCanvas().setRenderFlag( True )
  #msgBar.clearWidgets()
  """
  i= self.iface
  with open(chemin, 'r') as f:
    content = f.read()
    doc = QtXml.QDomDocument()
    doc.setContent(content)
    layernode = doc.elementsByTagName('maplayer').at(0)
    layerelm = layernode.toElement()
    layertype = layerelm.attribute("type")
    layer = None
    if layertype == "vector": layer = QgsVectorLayer()
    elif layertype == 'raster': layer = QgsRasterLayer()
    ok = layer.readLayerXml(layerelm, QgsReadWriteContext() )
    if ok:  QgsProject.instance().addMapLayer(layer)
  #"""
 #Fin affiche Qlr

 def afficheSpatialite(self, titre, chemin, qml):
  i= self.iface
  i.mapCanvas().setRenderFlag( False )
  macouche= QgsVectorLayer(chemin, titre, 'spatialite')
  QgsProject.instance().addMapLayer(macouche)
  i.mapCanvas().setRenderFlag( True )
 #Fin affiche Spatialite()

 def affichePostgres(self, titre, chemin, qml):
  i= self.iface
  i.mapCanvas().setRenderFlag( False )
  macouche= QgsVectorLayer(chemin, titre, 'postgres')
  QgsProject.instance().addMapLayer(macouche)
  i.mapCanvas().setRenderFlag( True )
 #Fin affiche Postgres()

 def afficheRaster(self, titre, chemin, qml):
  i= self.iface
  macouche= QgsRasterLayer( chemin, titre )
  if not macouche:  return
  i.mapCanvas().setRenderFlag( False )
  QgsProject.instance().addMapLayer(macouche,False) #prête à être utilisée mais pas encore affichée
  legendTree= self.iface.layerTreeView()
  grp= legendTree.currentGroupNode() #on veut ajouter la couche à la fin du groupe actif
  if not grp:  grp= QgsProject.instance().layerTreeRoot() # sinon à la base de la légende
  grp.addLayer(macouche) # ajouter à la fin car c'est du raster !
  if qml: # le chemin d'un éventuel qml 
    try: macouche.loadNamedStyle(qml)
    except: pass
  i.mapCanvas().setRenderFlag( True )
 #Fin affiche Raster()

 def afficheProjet(self, titre, chemin, qml):
  i= self.iface
  msgBox= QMessageBox( i.mainWindow() )
  msgBox.setWindowTitle( "Ouvrir un projet QGIS" )
  msgBox.setText( u"<strong>Projet : %s</strong>"% chemin )
  ouvreButton= msgBox.addButton(u"Fermer tout et ouvrir ce projet", QMessageBox.AcceptRole)
  ajoutButton= msgBox.addButton(u"Intégrer les couches de ce projet", QMessageBox.AcceptRole)
  annuleButton= msgBox.addButton(u"Annuler", QMessageBox.RejectRole)
  msgBox.setDefaultButton( ajoutButton )
  while True:
    msgBox.exec_()
    if msgBox.clickedButton() == ouvreButton:
       self.iface.mapCanvas().setRenderFlag( False )
       i.addProject( chemin )
       self.iface.mapCanvas().setRenderFlag( True )
    elif msgBox.clickedButton() == ajoutButton:
       self.integrerProjet( '', chemin, None ) 
    break # touche Echap ou Fermeture du msgBox
 #Fin affiche Projet()

 def integrerProjet(self, titre, chemin, qml):
  """ fonction qui peut etre lancée par un menu ou à partir de afficheProjet """
  treeRoot= QgsProject.instance().layerTreeRoot()
  #self.iface.mapCanvas().setRenderFlag( False )
  msgBar= iface.messageBar()
  msg= msgBar.createMessage("Merci de patienter pendant l'ouverture du fichier")
  msgBar.pushItem(msg)
  #msgBar.pushMessage("Patientez pendant l'ouverture du fichier", level=Qgis.Info, duration=5 )
  QApplication.processEvents()
  QgsLayerDefinition.loadLayerDefinition( chemin, QgsProject.instance(), treeRoot )
  msgBar.popWidget(msg)
  #self.iface.mapCanvas().setRenderFlag( True )
 #Fin integrer Projet()

 def OLD_integrerProjet(self, titre, chemin, qml): ### A SUPPRIMER ! ! 
  """ fonction qui peut etre lancée par un menu ou à partir de afficheProjet """
  fichier= chemin
  f= QFile( fichier )
  if not f.open(QIODevice.ReadOnly):  return
  self.iface.mapCanvas().setRenderFlag( False )
  doc= QtXml.QDomDocument()
  doc.setContent( f )
  maps= doc.elementsByTagName("maplayer")  # definition de chaque couche (fichier, style, etiquette...)
  nodeListe= doc.elementsByTagName("legend")
  legende= nodeListe.item(0) # le contenu de la legende, dans le projet Qgis à afficher
  
  def lireGroupe( domGrp, treeGrp ):
    elems = domGrp.childNodes()
    for N in range(elems.length()-1,-1,-1): # parcourir les couches du groupe en partant de la dernière
      ele = elems.item(N).toElement()
      
      if ele.tagName()=="legendgroup":
        nomGrpe = ele.attribute("name")
        treeItem = treeGrp.insertGroup( 0, nomGrpe )
        treeItem.setExpanded( True )
        lireGroupe( ele, treeItem )
        continue
        
      if not ele.tagName()=="legendlayer": continue
      nodeListe = ele.elementsByTagName("legendlayerfile")
      if not nodeListe.length()==1: continue
      layId = nodeListe.item(0).toElement().attribute("layerid")
      for i in range(maps.length()): # rechercher dans les couches du projet celle qui a layId
        item= maps.item(i)
        coucheIdElem= item.firstChildElement("id")
        coucheId= coucheIdElem.toElement().text()
        if not layId==coucheId: continue
        #QGIS refuse d'ouvrir 2 fois une couche avec le meme coucheId :
        while True: # Tester si coucheId existe deja et si oui, le modifier :
          test= treeRoot.findLayer(coucheId) #tester si coucheId existe deja
          if not test: break #Si coucheId n'existe pas, passer a la suite
          coucheId= coucheId +"2" #Modification basique de coucheId
          t= doc.createTextNode(coucheId)
          coucheIdElem.replaceChild(t, coucheIdElem.firstChild()) #Remplacer la valeur de "id"
        nomCouche = item.firstChildElement("layername").toElement().text()
        
        datasource= item.firstChildElement("datasource").toElement().text()
        provider= item.firstChildElement("provider").toElement().text()
        if provider.lower() in ['ogr','gdal'] and datasource[0:1]=='.':
          ds= datasource.split('|')
          ds[0]= os.path.normpath( os.path.dirname(fichier) +'/'+ datasource )
          datasource= '|'.join(ds)
        if provider.lower()=='wms' or provider.lower()=='gdal':
          nouvelleCouche= QgsRasterLayer(datasource, nomCouche, provider)
        else:
          nouvelleCouche= QgsVectorLayer(datasource, nomCouche, provider)
        if not nouvelleCouche: break
        nouvelleCouche.readXml( item, QgsReadWriteContext() ) # Lire les reglages de la couche
        QgsProject.instance().addMapLayer(nouvelleCouche,False) # Prête à être utilisée mais pas encore affichée
        new= treeGrp.insertLayer(0, nouvelleCouche) # En 1ere position
        new.setExpanded( False )
        if ele.attribute("checked")=="Qt::Unchecked": new.setItemVisibilityChecked(False) #retablie l'etat: affiché ou non
        break
  
  legendTree= self.iface.layerTreeView()
  treeRoot= QgsProject.instance().layerTreeRoot()
  #treeRoot = legendTree.currentGroupNode()
  #while treeRoot.parent(): #cherche la racine de la legende
  #  treeRoot = treeRoot.parent()
  groupe0= treeRoot.insertGroup(0,"Ouverture des couches en cours...")
  groupe0.setExpanded( True )
  lireGroupe( legende, groupe0 )
  groupe0.setName( titre )
  
  f.close()
  self.iface.mapCanvas().setRenderFlag( True )
 #Fin OLD integrer Projet()


 def afficheWMS(self, titre, chemin, qml):
  i= self.iface
  sep = "||" # séparateur: ||
  val= chemin
  lUri= val.split( sep )
  if len(lUri) == 1 : # c'est un simple lien web --> afficher dans un navigateur
    try: os.startfile(val) # ne fonctionne qu'avec Windows
    except: pass
    return
  if len(lUri) != 5 : return  # WMS mal défini
  
  """try:
    uri= u"url="+ lUri[0]
    uri= uri +"&layers="+ lUri[1]
    uri= uri +"&format="+ lUri[2] # 'image/png'
    uri= uri +"&crs="+ lUri[3] # 'EPSG:2154'
    uri= uri +"&styles="+ lUri[4]
    macouche= QgsRasterLayer( uri, titre, 'wms' )  ##macouche= i.addRasterLayer( uri, nomCouche, 'wms' )  """
  try:
    uri= "layers="+ lUri[1]
    uri= uri +"&format="+ lUri[2] # 'image/png'
    uri= uri +"&crs="+ lUri[3] # 'EPSG:2154'
    uri= uri +"&styles="+ lUri[4]
    uri= uri +"&url="+ lUri[0]
    macouche= QgsRasterLayer( uri, titre, 'wms' )
  except: return
  if not macouche: return
  
  #if macouche: coucheId= macouche.id()     else: return
  i.mapCanvas().setRenderFlag( False )
  QgsProject.instance().addMapLayer(macouche,False) # Prête à être utilisée mais pas encore affichée
  grp= i.layerTreeView().currentGroupNode() # On veut ajouter la couche à la fin du groupe actif
  #if not grp:  grp= QgsProject.instance().layerTreeRoot() # Sinon en bas de la légende
  new= grp.addLayer(macouche) # ajouter à la fin car c'est du raster !
  
  i.mapCanvas().setRenderFlag( True )
  #new= grp.findLayer(macouche) # Retrouver la couche dans la legende
  if new:  new.setExpanded( False ) # Ne pas afficher la "legende" de la couche
 #Fin affiche WMS()

 def afficheWMTS(self, titre, chemin, qml):
  i= self.iface
  sep= "||" # séparateur: ||
  val= chemin
  lUri= val.split( sep )
  if len(lUri) == 1 : # c'est un simple lien web --> afficher dans un navigateur
    try: os.startfile(val) # ne fonctionne qu'avec Windows
    except: pass
    return
  if len(lUri) != 6 :  # WMTS mal défini
    i.messageBar().pushMessage("!!",u"La définition de cette couche WMTS est incorrecte : il manque des paramètres importants",level=0,duration=3)
    return
  
  try:
    uri= u"url="+ lUri[0]
    uri= uri +"&layers="+ lUri[1]
    uri= uri +"&format="+ lUri[2] # 'image/png'
    uri= uri +"&crs="+ lUri[3] # 'EPSG:2154'
    uri= uri +"&tileMatrixSet="+ lUri[4]
    uri= uri +"&styles="+ lUri[5]
    uri= uri +"&contextualWMSLegend=0&dpiMode=7&featureCount=10"
    #uri= u"contextualWMSLegend=0&crs=EPSG:3857&dpiMode=7&featureCount=10&format=image/png &layers=LANDUSE.AGRICULTURE2010&styles=normal&tileMatrixSet=PM &url=http://gpp3-wxs.ign.fr/yvy50i11nfshjkygutrd98un/wmts?SERVICE%3DWMTS%26request%3DGetCapabilities"
    macouche= QgsRasterLayer( uri, titre, 'wms' )  ##macouche= i.addRasterLayer( uri, nomCouche, 'wms' )
  except:
    i.messageBar().pushMessage("!!",u'Echec : la couche "'+ titre +"\" n'a pas réussi à s'ouvrir",level=0,duration=3)
    return
  if not macouche: return
  
  i.mapCanvas().setRenderFlag( False )
  QgsProject.instance().addMapLayer(macouche,False) # Prête à être utilisée mais pas encore affichée
  grp= i.layerTreeView().currentGroupNode() # On veut ajouter la couche à la fin du groupe actif
  new= grp.addLayer(macouche) # ajouter à la fin car c'est du raster !
  
  i.mapCanvas().setRenderFlag( True )
  if new:  new.setExpanded( False ) # Ne pas afficher la "legende" de la couche
 #Fin affiche WMTS()

 def afficheWFS(self, titre, chemin, qml):
  i= self.iface
  sep= "||" # séparateur: ||
  val= chemin
  lUri = val.split( sep )
  if len(lUri) != 5 : return  # WFS mal défini
  
  try:
    ##uri= lUri[0] + "?SERVICE=WFS&VERSION="
    uri= lUri[0]
    if not '?' in uri:  uri= uri +'?'
    elif uri[-1]!='?': uri= uri +'&'
    uri= uri +"SERVICE=WFS&VERSION="
    uri= uri + lUri[1] +"&REQUEST=GetFeature&TYPENAME="
    uri= uri + lUri[2]
    uri= uri + "&SRSNAME=" + lUri[3]
    cache= lUri[4]
    if cache=="non":  uri= uri +"&BBOX=0,0,1,1" # BBOX bidon qui empeche Qgis de mettre toute la couche en cache dés l'ouverture
    macouche= QgsVectorLayer(uri, titre, 'WFS')  #i.addVectorLayer( uri, titre, "WFS" )
    QgsProject.instance().addMapLayer(macouche)
  except:
    i.messageBar().pushMessage("!!",u'Echec : la couche "'+ titre +"\" n'a pas réussi à s'ouvrir",level=0,duration=3)
 #Fin affiche WFS()

 def afficheWeb(self, titre, chemin, qml):
  try: os.startfile( chemin ) # ne fonctionne qu'avec Windows
  except: pass
 #Fin affiche Web()

 def afficheAutreFichier(self, titre, chemin, qml):
  try: os.startfile( chemin ) # ne fonctionne qu'avec Windows
  except: pass
 #Fin affiche AutreFichier()

 def execPython(self, titre, chemin, arguments):
  i= self.iface
  nomfic= os.path.splitext( os.path.basename( chemin ) )[0] # le nom du fichier sans son extension
  """
  import importlib #.util
  if nomfic in sys.modules:  # Recharger
    # importlib.reload(sys.modules[nomfic])
    print( "sys.getrefcount(%s) :"%nomfic, sys.getrefcount(nomfic) )
    del sys.modules[nomfic]
    #del nomfic
  # """
  try:
    spec= importlib.util.spec_from_file_location(nomfic, chemin)
    module= importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # sys.modules[nomfic]= module
  except Exception as e: # Type d'exception: e.__class__.__name__
    if hasattr(e, 'msg'): erreur= e.msg
    elif hasattr(e, 'message'): erreur= e.message
    else: erreur= repr(e)
    i.messageBar().pushMessage( e.__class__.__name__, erreur +' '+ chemin, level=2, duration=5)
    return
  """
  try: 
    if nomfic in sys.modules:  # Recharger
      imp.reload(sys.modules[nomfic])
    else:
      module= imp.load_source(nomfic, chemin)
      sys.modules[nomfic]= module
  except Exception as e: # Type d'exception: e.__class__.__name__
    if hasattr(e, 'msg'): erreur= e.msg
    elif hasattr(e, 'message'): erreur= e.message
    else: erreur= repr(e)
    i.messageBar().pushMessage( e.__class__.__name__, erreur, level=2, duration=5)
    return
  # """
  try:
    module.action( i, arguments )
    #print( 'module.action( i )' )
  except AttributeError as e:
    if hasattr(e, 'msg'): erreur= e.msg
    elif hasattr(e, 'message'): erreur= e.message
    else: erreur= repr(e)
    #i.messageBar().pushMessage( e.__class__.__name__, erreur, level=2, duration=5)
    print( e.__class__.__name__, erreur )
 #Fin exec Python()

 def openComposer(self, titre, chemin, zoom):
  i= self.iface
  f= QFile(chemin)
  f.open(QIODevice.ReadOnly)
  doc= QtXml.QDomDocument()
  doc.setContent( f )
  f.close()
  
  projet= QgsProject.instance()
  compo= QgsPrintLayout(projet)
  if not compo.readLayoutXml( doc.documentElement(), doc, QgsReadWriteContext() ):
    ### readLayoutXml ne semble pas accepter les modeles de QGIS2 ; on teste une autre methode :
    items, ok= compo.loadFromTemplate( doc, QgsReadWriteContext() )
    if not ok:
      i.messageBar().pushMessage("Echec", "Ce modèle de composeur ne semble pas valide. QGIS n'a pas réussi à le lire", level=1, duration=10)
      return
  """compo.initializeDefaults()
    items, ok= compo.loadFromTemplate( doc, QgsReadWriteContext() )
    print( items )
    if not ok:
      i.messageBar().pushMessage("Echec", "Le Gestionnaire de mise en page n'a pas accepté ce composeur. Peut-être un soucis avec le modèle ?", level=1, duration=10)
      return
    compo.updateSettings() #"""
  layoutName= compo.name()
  """import codecs # for DEBUG
    with codecs.open("D:\#DDT\\QGIS\\TESTS\\C1.txt",'w','cp1252') as f:
      f.write( "apres loadFromTemplate" ) #"""
  
  manager= projet.layoutManager()
  layouts_list= manager.printLayouts()
  newName= layoutName
  for layout in layouts_list: # Chercher si le nom du nouveau compo existe deja parmi les compo existants
    if layout.name()==layoutName:
      newName= layoutName +"_" +QDateTime.currentDateTime().toString('yyyyMMdd-hhmmss')
      #manager.generateUniqueTitle()
      compo.setName(newName)
      break
  
  if not manager.addLayout(compo):
    i.messageBar().pushMessage("Echec", "Le Gestionnaire de mise en page n'a pas accepté ce composeur. Peut-être un soucis avec le modèle ?", level=1, duration=10)
    return
  
  """i.showLayoutManager() # for DEBUG
    ret= QMessageBox.question(i.mainWindow(), "Test", "Voulez-vous ouvrir le compo : "+ newName)
    if ret!=QMessageBox.Yes: return #"""
  ldi= i.openLayoutDesigner(compo) # Afficher le compo
  
  if newName != layoutName: # S'il a fallu renommer le compo
    QMessageBox.about( ldi.window(), "Remarque sur le nom du composeur",
      "Il y avait déjà un composeur \"%s\".\n\nLe nouveau s'intitule \"%s\"."% (layoutName,newName) )
  
  # Faut-il zoomer la carte sur canvas extents ?
  if zoom=='no' or zoom=='non': return
  m= compo.referenceMap()
  if m==None:  return
  try:  m.zoomToExtent(i.mapCanvas().extent())
  except:  pass
 #Fin open Composer() """


 def reload(self):
  self.unload()
  self.initGui()

 def unload(self):
  # supprimer le "Menus perso" du menu Extension :
  self.extensionMenuPerso.parentWidget().removeAction(self.extensionMenuPerso.menuAction())
  # supprimer les menus du xml :
  for m in self.refqm:
    m.parentWidget().removeAction(m.menuAction())
  try: self.toolBar.removeAction( self.boutonVersion )
  except: pass

