# -*- coding: utf_8 -*-
""" -----------------------------------------------
 basé sur le code de : Eli Bendersky (eliben@gmail.com)
 --> qsci_simple_pythoneditor.pyw
 This code is in the public domain
 -------------------------------------------------- """
import codecs, os, os.path
from PyQt5.QtCore import Qt, QCoreApplication, QSettings, QLocale, QFileInfo, QTranslator, QUrl
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtWidgets import QApplication, QAction, QMessageBox, QFileDialog, QDialog, QGridLayout, QHBoxLayout, QToolBar, QPushButton, QDockWidget, QTreeWidget
#from PyQt5 import QtWebEngineWidgets # QtWebEngine #import QWebEnginePage  #from PyQt5 import QtWebKit
from PyQt5.QtWebKitWidgets import QWebView

class xmlEditor(QDialog):
  ARROW_MARKER_NUM = 8
  def tr(self, txt, disambiguation=None):
    return QCoreApplication.translate('xmlEditor', txt, disambiguation)
    
  def __init__(self, parent, fichier, foncReload):
    self.path = os.path.abspath(os.path.dirname(__file__))
    # i18n support
    overrideLocale = QSettings().value("locale/overrideFlag", False)
    localeFullName = QLocale.system().name() if not overrideLocale else QSettings().value("locale/userLocale", "")
    i18Path= os.path.abspath( self.path +os.sep+'..'+os.sep+ 'i18n' )+ os.sep
    traduc= i18Path +"menus_" + localeFullName[0:2] + ".qm" #menus_fr.qm
    #if localeFullName[0:2] == "fr" : reload(sys) ; sys.setdefaultencoding('iso-8859-1')
    if not QFileInfo(traduc).exists(): # si pas de menus_fr.qm, on cherche menus_fr_FR.qm
      traduc = i18Path +"menus_" + localeFullName + ".qm"
    if QFileInfo(traduc).exists():
      self.translator = QTranslator()
      self.translator.load(traduc)
      QCoreApplication.installTranslator(self.translator)
    
    try:
      from PyQt5.Qsci import QsciScintilla, QsciScintillaBase, QsciLexerXML, QsciAPIs
    except: #u"L'éditeur de code est introuvable.\nLe module 'QScintilla' n'est pas installé."
      QMessageBox.critical( parent, self.tr("Warning"),
       self.tr("Menu editor failed to start : QScintilla module is not installed"))
      return
    
    self.reload = foncReload # fonction qui met à jour les menus (à appeler quand on enregistre le fichier xml)
    self.fichier = fichier
    flags = Qt.WindowTitleHint | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint # | Qt.WindowStaysOnTopHint | Qt.WindowSystemMenuHint
    QDialog.__init__(self, parent, flags)
    self.ed = QsciScintilla(self)
    gridLayout1 = QGridLayout(self)
    gridLayout1.setContentsMargins( 0, 0, 0, 0 )
    hLayout2 = QHBoxLayout()
    gridLayout1.addLayout(hLayout2, 0, 0)
    gridLayout1.addWidget(self.ed, 1, 0) #, 1, 1)
    bSave = QPushButton(self.tr('Save')) #u'Enregistrer'
    bSave.clicked.connect(self.saveChanges)
    bSave.setToolTip(self.tr("<p>Save changes<br />then update menus.</p>")+ "<br /><br /><br />")
    #<p>Sauvegarder les modifications apportées au fichier<br />puis appliquer ces changements dans les menus.</p>
    hLayout2.addWidget(bSave)
    
    self.bAide = QPushButton(self.tr("Help"),self)
    self.bAide.clicked.connect(self.aide)
    hLayout2.addWidget(self.bAide)
    self.ed.setUtf8(True) # permet saisie des accents (requis meme pour cp1252)
    
    lexer = QsciLexerXML(self) # Choose a lexer
    api = QsciAPIs(lexer)
    api.prepare() # Compile the api for use in the lexer
    # Tell the editor we are using any installed APIs for the autocompletion
    self.ed.setAutoCompletionSource(QsciScintilla.AcsAPIs)
    # Set the length of the string before the editor tries to autocomplete
    self.ed.setAutoCompletionThreshold(2)
    self.ed.setLexer(lexer)
    
    font = QFont() # Set the default font
    font.setFamily('Courier')
    font.setFixedPitch(True)
    font.setPointSize(12)
    self.ed.setFont(font)
    
    font.setFamily('Helvetica')
    font.setPointSize(9)
    self.ed.setMarginsFont(font)
    large = '9999'
    self.ed.setMarginWidth(0, large) # Margin 0 is used for line numbers
    self.ed.setMarginLineNumbers(0, True)
    self.ed.setMarginWidth(1,1) # la marge entre num lignes et blocs
    
    self.ed.setMarginsBackgroundColor(QColor("#cccccc"))
    # Brace matching: enable for a brace immediately before or after the current position :
    self.ed.setBraceMatching(QsciScintilla.SloppyBraceMatch)
    # Current line visible with special background color :
    self.ed.setCaretLineVisible(True)
    self.ed.setCaretLineBackgroundColor(QColor("#ffe4e4"))
    
    # Use raw message to Scintilla here (all messages are documented here:  http://www.scintilla.org/ScintillaDoc.html)
    self.ed.setTabWidth(2) # tab=2 car
    self.ed.setIndentationsUseTabs(False) # remplace tabs par car
    self.ed.setIndentationWidth(0) # indent = tabWidth
    self.ed.setTabIndents(True) #tab key will indent a line rather than insert a tab character
    self.ed.setBackspaceUnindents(True) #backspace key will unindent a line
    self.ed.setAutoIndent( True )
    self.ed.setIndentationGuides( True )
    self.ed.setFolding(QsciScintilla.BoxedTreeFoldStyle) # Folding visual : we will use boxes
    self.ed.setFoldMarginColors(QColor("#99CC66"),QColor("#AAAAAA"))
    
    self.ed.setWrapMode( QsciScintilla.WrapWord )
    self.ed.setWrapIndentMode( QsciScintilla.WrapIndentSame )
    
    self.ed.setText( codecs.open(fichier,'r','cp1252','replace').read() ) # Show this file in the editor
  #Fin __init__

  def aide(self):
    #form = QDialog(self)
    form = QDialog( self.ed )
    form.setWindowTitle( self.tr("Create Menus Guide") )
    #u"Mode d'emploi de l'extension : Créer Menus"
    fen= QWebView(form) #QtWebKit.QWebView(form)
    Layout_1 = QGridLayout(form)
    Layout_1.setContentsMargins( 0, 0, 0, 0 )
    Layout_1.addWidget(fen, 0, 0, 1, 1)
    
    PluginPath = os.path.abspath(os.path.dirname(__file__) + os.sep +"..") + os.sep
    overrideLocale= QSettings().value("locale/overrideFlag", False)
    locale= QLocale.system().name() if not overrideLocale else QSettings().value("locale/userLocale", "")
    ficAide= PluginPath +"help_"+ locale[0:2] +'.html' #help_fr.html
    if not QFileInfo(ficAide).exists(): # si pas de help_fr.html, on cherche help_fr_FR.html
      ficAide= PluginPath +"help_"+ locale +'.html'
    if not QFileInfo(ficAide).exists():
      ficAide= PluginPath +'help.html'
    
    ficAide= 'file:///'+ ficAide.replace('\\','/')
    fen.load( QUrl(ficAide) ) #setUrl( QUrl(ficAide) )
    
    form.show() #form.exec_()
  #Fin aide()

  def saveChanges(self, checked=False):
    with codecs.open(self.fichier,'w','cp1252') as f:
      f.write( self.ed.text() )
    self.reload()

  def on_margin_clicked(self, nmargin, nline, modifiers):
    # Toggle marker for the line the margin was clicked on
    if self.ed.markersAtLine(nline) != 0:
      self.ed.markerDelete(nline, self.ARROW_MARKER_NUM)
    else:
      self.ed.markerAdd(nline, self.ARROW_MARKER_NUM)
