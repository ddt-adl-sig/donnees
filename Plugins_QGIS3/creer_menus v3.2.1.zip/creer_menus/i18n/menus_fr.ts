<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>Menus</name>
    <message>
        <location filename="../Menus.py" line="95"/>
        <source>Plugin: Create menus  (version %s)</source>
        <translation>Extension : Créer ses menus  (version %s)</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="96"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="104"/>
        <source>&lt;strong&gt;The file that contains the description of the menus is not defined !&lt;/strong&gt;</source>
        <translation>&lt;strong&gt;Vous n&apos;avez pas choisi le fichier qui contient la description des menus&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="105"/>
        <source>Choose a file</source>
        <translation>Choisir un fichier</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="108"/>
        <source>The file that contains the description of the menus is:</source>
        <translation>Le fichier qui contient la description des menus se trouve ici :</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="109"/>
        <source>Choose another file</source>
        <translation>Choisir un autre fichier</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="111"/>
        <source>Create from template</source>
        <translation>Créer depuis le modèle</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="112"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="113"/>
        <source>At its first start, the plugin copies a template file &lt;strong&gt;Menus.xml&lt;/strong&gt; to the folder &lt;u&gt;USERPROFILE/.qgis2&lt;/u&gt;. It adds a menu &lt;u&gt;Shortcuts&lt;/u&gt; with a few examples of layers.&lt;/p&gt; &lt;p&gt;This is the file to edit to create your menus. You can move that file to another folder then press button &lt;u&gt;Choose another file&lt;/u&gt; to point the plugin to its new place.</source>
        <translation>Au premier démarrage de l&apos;extension, elle va créer un fichier &lt;strong&gt;Menus.xml&lt;/strong&gt; dans le dossier &lt;u&gt;USERPROFILE/.qgis2&lt;/u&gt; avec un menu &lt;u&gt;Raccourcis&lt;/u&gt; et quelques exemples de couches (dont les raccourcis vers les WMS de GéoRef).&lt;/p&gt; &lt;p&gt;Vous pourrez personnaliser vos menus en modifiant ce fichier. Si vous déplacez ce fichier, il faudra indiquer à l&apos;extension où vous l&apos;avez placé avec le bouton &lt;u&gt;Choisir un autre fichier&lt;/u&gt;.</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="118"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="36"/>
        <source>&amp;Create menus</source>
        <translation>&amp;Créer ses propres menus</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="46"/>
        <source>&amp;Set Menus definition file</source>
        <translation>&amp;Définir l&apos;emplacement du fichier qui décrit les menus</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="47"/>
        <source>Choose Menus definition file</source>
        <translation>Choisir le fichier des menus</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="51"/>
        <source>&amp;Help   (version %s)</source>
        <translation>&amp;Aide  (version %s)</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="52"/>
        <source>User guide</source>
        <translation>Mode d&apos;emploi</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="40"/>
        <source>&amp;Edit Menus definition file</source>
        <translation>Afficher/&amp;modifier le fichier des menus</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="87"/>
        <source>File: </source>
        <translation>Fichier : </translation>
    </message>
    <message>
        <location filename="../Menus.py" line="146"/>
        <source>Menus definitions file is here:
</source>
        <translation>Le fichier qui contient la description des menus se trouve ici :
</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="139"/>
        <source>Template copy failed.
 Please, choose another file name.</source>
        <translation>La copie du modèle a échoué.\n Merci de choisir un autre nom de fichier.</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="143"/>
        <source>Template copy failed.
 Please, choose another folder.</source>
        <translation>La copie du modèle a échoué.\n Merci de choisir un autre dossier.</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="155"/>
        <source>File : </source>
        <translation>Fichier : </translation>
    </message>
    <message>
        <location filename="../Menus.py" line="171"/>
        <source>Sorry but you can&apos;t put your file in the plugin folder.</source>
        <translation>Désolé, vous ne pouvez pas placer votre fichier dans le dossier du plugin.</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="179"/>
        <source>Create Menus Guide</source>
        <translation>Mode d&apos;emploi de l&apos;extension : Créer ses propres menus</translation>
    </message>
    <message>
        <location filename="../Menus.py" line="124"/>
        <source>Choose Menus file</source>
        <translation>Choisir le fichier des Menus</translation>
    </message>
</context>
<context>
    <name>xmlEditor</name>
    <message>
        <location filename="../editor/editorGui.py" line="36"/>
        <source>Warning</source>
        <translation>Echec</translation>
    </message>
    <message>
        <location filename="../editor/editorGui.py" line="36"/>
        <source>Menu editor failed to start : QScintilla module is not installed</source>
        <translation>L&apos;éditeur de menus n&apos;a pas pu démarrer.\nLe module &apos;QScintilla&apos; n&apos;est pas installé</translation>
    </message>
    <message>
        <location filename="../editor/editorGui.py" line="50"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../editor/editorGui.py" line="52"/>
        <source>&lt;p&gt;Save changes&lt;br /&gt;then update menus.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Enregistre les modifications apportées au fichier&lt;br /&gt;puis applique ces changements dans les menus.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../editor/editorGui.py" line="56"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../editor/editorGui.py" line="110"/>
        <source>Create Menus Guide</source>
        <translation>Mode d&apos;emploi de l&apos;extension : Créer ses propres menus</translation>
    </message>
</context>
</TS>
